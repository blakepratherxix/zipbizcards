//
//  CardCell.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 23/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit

class CardCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDetail: UILabel!
    @IBOutlet weak var switchPhoto: UISwitch!
    
    @IBOutlet weak var btnCheck: UIButton!
    @IBOutlet weak var tfInformation: UITextField!
    
    @IBOutlet weak var imageviewIcon: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
