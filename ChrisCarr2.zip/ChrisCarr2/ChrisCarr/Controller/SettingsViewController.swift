//
//  SettingsViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 11/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import MessageUI


class SettingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {
    

    
    //MARK: Properties
    let arrayOptions:NSArray = ["About the App","Rate the App","Terms and Conditions","Send Feedback"]
    let arrayOptions_images:NSArray = ["about","rating","tc","feedback"]
    
    //MARK: Outlets
    @IBOutlet weak var settingsTableview: UITableView!
    
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        self.settingsTableview.tableFooterView = UIView.init(frame: CGRect.zero)
    }
    
    
    //MARK:- Utility Methods
    
    
    //MARK:- Action Methods
    
    @IBAction func btnBack_Action(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = "cell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifier)
        cell?.imageView?.image = UIImage.init(named: "")
        cell?.textLabel?.text = self.arrayOptions.object(at: indexPath.row) as? String
        cell?.imageView?.image  = UIImage.init(named: (self.arrayOptions_images.object(at: indexPath.row) as? String)!) 
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "AboutViewController")
            self.navigationController?.pushViewController(vc!, animated: true)
            break
            
        case 1:
            CommonClass.sharedInstance.showAlertView(vc: self, title: "Please tell us,\nif you satisfied with the work of the application?", message: "", buttons: ["No","Yes","Cancel"]) { (buttonText, alertController) in
                if (buttonText == "No" || buttonText == "Cancel"){
                    alertController.dismiss(animated: true, completion: nil)
                }else{
                    let url = URL.init(string: "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=545174222&onlyLatestVersion=true&pageNumber=0&sortOrdering=1&type=Purple+Software")
                    UIApplication.shared.open(url!, options: [:], completionHandler: nil)
                }
            }
            
            break
            
        case 2:
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TCViewController")
            self.navigationController?.pushViewController(vc!, animated: true)
            break
            
        case 3:
            if MFMailComposeViewController.canSendMail(){
                let emailController = MFMailComposeViewController.init()
                emailController.setToRecipients(["feedback@chriscarr.com"])
                emailController.setSubject("Feedback ~ ZipBizCards")
                emailController.mailComposeDelegate = self
                self.present(emailController, animated: true, completion: nil)
                
                
            }else{
                CommonClass.sharedInstance.showAlertView(vc: self, title: "Email Not Configured", message: "Please configure your email in phone settings", buttons: ["Ok"]) { (btnText, avc) in
                }
            }
            break
        default:
            break
        }
    }
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    
    //MARK: Email Controller Delegate
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
