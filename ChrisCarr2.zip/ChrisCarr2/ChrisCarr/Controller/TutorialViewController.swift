//
//  TutorialViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 11/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit

class TutorialViewController: UIViewController, UIScrollViewDelegate {
    
    //MARK: Properties
    
    var currentPage = 0
    
    //MARK: Outlets
    
    @IBOutlet weak var tutorialScrollview: UIScrollView!
    @IBOutlet weak var btnSkip: UIButton!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.tutorialScrollview.contentSize = CGSize.init(width: (self.view.bounds.width*3), height: 0)
    }

    //MARK:- View Setup Methods
    func setupView() {
        self.tutorialScrollview.delegate = self
        
    }
    
    
    //MARK:- Utility Methods
    func calculatePage() {
        let pageNumber                  = round(self.tutorialScrollview.contentOffset.x / self.tutorialScrollview.frame.size.width)
        self.setCurrentPage(pageNumner: Int(pageNumber))
    }
    func nextPage() {
        let nextPageNumber = self.currentPage + 1
        if (nextPageNumber < 3){
            self.gotoPage(page: nextPageNumber)
        }else{
            self.isOnboardingScreensViewed()
            self.btnSkip_Action(0)
        }
    }
    
    func gotoPage(page:Int){
        let x = CGFloat(page) * self.tutorialScrollview.frame.size.width
        self.tutorialScrollview.setContentOffset(CGPoint(x:x, y:0), animated: true)
    }
    
    func setCurrentPage(pageNumner:Int) {
        self.currentPage                = pageNumner
        self.pageControl.currentPage    = self.currentPage
    }
    
    func isOnboardingScreensViewed() {
        let userDefault = UserDefaults.standard
        userDefault.set(true, forKey: "onboardingScreensViewed")
    }
    
    
    
    //MARK:- Action Methods
    
    @IBAction func btnSkip_Action(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController")
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func btnNext_Action(_ sender: Any) {
        self.nextPage()
    }
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.calculatePage()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        self.calculatePage()
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        self.calculatePage()
    }
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
