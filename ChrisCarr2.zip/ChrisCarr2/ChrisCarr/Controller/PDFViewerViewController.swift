//
//  PDFViewerViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 11/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import WebKit

class PDFViewerViewController: UIViewController {

    
    //MARK: Properties
    var selectedCard:Card!
    var paperSize:String!
    var fileURL:URL!
    
    
    //MARK: Outlets
    @IBOutlet weak var lblPaperSize: UILabel!
    @IBOutlet weak var webview: WKWebView!
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        self.lblPaperSize.text  = "Paper Size - " + self.paperSize
        self.loadPDF(filename: "sample1.pdf")
    }
    
    
    //MARK:- Utility Methods
    func loadPDF(filename: String) {
        let path = NSTemporaryDirectory().appending(filename)
        self.fileURL = NSURL(fileURLWithPath: path) as URL
        let urlRequest = NSURLRequest.init(url: self.fileURL)
        self.webview.load(urlRequest as URLRequest)
    }
    
    //MARK:- Action Methods
    
    @IBAction func btnBack_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnForward_Action(_ sender: UIButton) {
        
        do {
            let pdf = try Data.init(contentsOf: self.fileURL)
            
            if UIPrintInteractionController.canPrint(pdf){
                let printInfo           = UIPrintInfo(dictionary: nil)
                printInfo.jobName       = (self.selectedCard.name?.text)!
                printInfo.outputType    = .photo
                
                let printController 	            = UIPrintInteractionController.shared
                printController.printInfo           = printInfo
                printController.showsNumberOfCopies = true
                printController.printingItem        = pdf
                printController.present(animated: true) { (myPrinterController, Status, Err) in
                    
                };
            }else{
                let alert = UIAlertController(title: "Error", message: "File can not be printed", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        } catch {
            print("Error Reading PDF file")
        }
        
    }
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
