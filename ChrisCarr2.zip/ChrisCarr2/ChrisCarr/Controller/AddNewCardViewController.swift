//
//  AddNewCardViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 23/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit

class AddNewCardViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate  {
    
    
    //MARK: Properties
    let arraySectionNames:NSArray   = [" ","Name","Occupation","Company","Contacts","Address"]
    var isPhoto:Bool                = true
    
    
    
    // Name
    var isName:Bool             = true
    var name:String!            = "" //"Azeem Akram" //
    // Occupation
    var isOccupation:Bool       = true
    var occupation:String!      = ""
    // Company Name
    var isCompanyName:Bool      = true
    var companyName:String!     = ""
    // Mobile Number
    var isMobileNumber:Bool     = true
    var mobileNumber:String!    = ""
    // Telephone Numbebr
    var isTelephoneNumber:Bool  = true
    var telephoneNumber:String! = ""
    // Email
    var isEmail:Bool            = true
    var email:String!           = ""
    // Address
    var isAddress:Bool          = true
    var address:String!         = ""
    
    
    //General
    var tfSelected:UITextField!
    
    //MARK: Outlets
    
    @IBOutlet weak var tableviewData: UITableView!
    
    @IBOutlet weak var tableviewBottomConstraint: NSLayoutConstraint!
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        let appDelegate     = UIApplication.shared.delegate as! AppDelegate
        let context         = appDelegate.persistentContainer.viewContext
        
        CommonClass.sharedInstance.myCard                       = Card.entityDescription(context: context)
        CommonClass.sharedInstance.myCard.backgroundImageName   = ""
        CommonClass.sharedInstance.myCard.lineColor             = ""
        CommonClass.sharedInstance.isNewCardInProgress  	    = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.updatePhoto(notification:)), name: Notification.Name.init(rawValue: "setBackgroundPhoto"), object: nil)
    }
    
    
    //MARK:- Utility Methods
    
    func gotoSelectBackground() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SelectBGViewController")
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @objc func updatePhoto(notification:NSNotification) {
        self.tableviewData.reloadData()
    }
    
    func isValidData() -> Bool {
        let whitespace = NSCharacterSet.whitespaces

        if (self.isName && self.name.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter name", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        
        if (self.isOccupation && self.occupation.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter occupation", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        if (self.isCompanyName && self.companyName.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter company name", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        if (self.isMobileNumber && self.mobileNumber.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter mobile number", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        if (self.isTelephoneNumber && self.telephoneNumber.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter home number", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        if (self.isEmail && self.email.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter email", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        
        if self.isEmail && self.email.trimmingCharacters(in: whitespace).count > 0 && !(CommonClass.sharedInstance.isValidEmail(testStr: self.email)) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter valid email", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        
        if (self.isAddress && self.address.trimmingCharacters(in: whitespace).count <= 0) {
            CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter address", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
            })
            return false
        }
        
        
        return true
    }
    
    //MARK:- Action Methods
    
    @IBAction func photoSwitch_Action(_ sender: UISwitch) {
        self.isPhoto    = sender.isOn
    }
    
    @IBAction func btnCheck_Action(_ sender: UIButton) {
        let cell            = sender.superview?.superview as! CardCell
        let indexPath       = self.tableviewData.indexPath(for: cell)
        
        sender.isSelected               = !sender.isSelected
        
        cell.tfInformation.resignFirstResponder()
        cell.tfInformation.isEnabled    = sender.isSelected
        cell.tfInformation.textColor    = sender.isSelected ? UIColor.black : UIColor.lightGray
        
        if indexPath!.section == 1{
            self.isName   = sender.isSelected
        }else if indexPath!.section == 2{
            self.isOccupation = sender.isSelected
        }else if indexPath!.section == 3{
            self.isCompanyName = sender.isSelected
        }else if indexPath!.section == 4{
            if indexPath!.row == 0{
                self.isMobileNumber = sender.isSelected
            }else if indexPath!.row == 1{
                self.isTelephoneNumber = sender.isSelected
            }else{
                self.isEmail  = sender.isSelected
            }
        }else{
            self.isAddress    = sender.isSelected
        }
    }
    
    @IBAction func btnCancel_Action(_ sender: UIButton) {
        CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Are you sure to cancel?", buttons: ["Yes", "No"], completionHandler: { (buttonText, viewController) in
            if buttonText.range(of: "Yes") != nil {
                let appDelegate     = UIApplication.shared.delegate as! AppDelegate
                let context         = appDelegate.persistentContainer.viewContext
                context.delete(CommonClass.sharedInstance.myCard)
                do {
                    try context.save()
                    CommonClass.sharedInstance.myCard = nil
                    CommonClass.sharedInstance.myCardBackgroundImage = nil
                    self.dismiss(animated: true, completion: nil)
                } catch {
                    print("Failed saving")
                }
            }
        })
        
    }
    
    @IBAction func btnNext_Action(_ sender: UIButton) {
        if self.tfSelected != nil {
            self.tfSelected.resignFirstResponder()            
        }
        
        if self.isValidData() {
            let appDelegate     = UIApplication.shared.delegate as! AppDelegate
            let context         = appDelegate.persistentContainer.viewContext
            
            let cardPhoto           = Photo.entityDescription(context: context)
            cardPhoto.isOn          = self.isPhoto
            cardPhoto.imageName     = ""
            
            let cardName            = Name.entityDescriptionForDefaultSettings(context: context)
            cardName.isOn           = self.isName
//            if (self.isName && self.name.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter name", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            let cardOccupation      = Occupation.entityDescriptionForDefaultSettings(context: context)
            cardOccupation.isOn     = self.isOccupation
//            if (self.isOccupation && self.occupation.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter occupation", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            let cardCompany         = Company.entityDescriptionForDefaultSettings(context: context)
            cardCompany.isOn        = self.isCompanyName
//            if (self.isCompanyName && self.companyName.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter company name", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            let cardMobileNumber    = MobileNumber.entityDescriptionForDefaultSettings(context: context)
            cardMobileNumber.isOn   = self.isMobileNumber
//            if (self.isMobileNumber && self.mobileNumber.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter mobile number", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            let cardHomeNumber      = HomeNumber.entityDescriptionForDefaultSettings(context: context)
            cardHomeNumber.isOn     = self.isTelephoneNumber
//            if (self.isTelephoneNumber && self.telephoneNumber.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter home number", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            let cardEmail           = Email.entityDescriptionForDefaultSettings(context: context)
            cardEmail.isOn          = self.isEmail
//            if (self.isEmail && self.email.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter email", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            let cardAddress         = Address.entityDescriptionForDefaultSettings(context: context)
            cardAddress.isOn        = self.isAddress
//            if (self.isAddress && self.address.count <= 0) {
//                CommonClass.sharedInstance.showAlertView(vc: self, title: alertTitle, message: "Please enter address", buttons: ["Ok"], completionHandler: { (buttonText, viewController) in
//                })
//                return
//            }
            
            if CommonClass.sharedInstance.selectedBackgroundType == ImagesType.ImagesTypeDark {
                let code                = "#ffffff"
                cardName.color          = code
                cardOccupation.color    = code
                cardCompany.color       = code
                cardMobileNumber.color  = code
                cardHomeNumber.color    = code
                cardEmail.color         = code
                cardAddress.color       = code
            }
            
            if self.isName {
                cardName.text       = self.name
            }
            if isOccupation{
                cardOccupation.text = self.occupation
            }
            if  isCompanyName {
                cardCompany.text    = self.companyName
            }
            if isMobileNumber {
                cardMobileNumber.text   = self.mobileNumber
            }
            if isTelephoneNumber {
                cardHomeNumber.text = self.telephoneNumber
            }
            if isEmail{
                cardEmail.text      = self.email
            }
            if isAddress {
                cardAddress.text    = self.address
            }
            
            
            CommonClass.sharedInstance.myCard.name         = cardName
            CommonClass.sharedInstance.myCard.occupation   = cardOccupation
            CommonClass.sharedInstance.myCard.company      = cardCompany
            CommonClass.sharedInstance.myCard.mobileNumber = cardMobileNumber
            CommonClass.sharedInstance.myCard.homeNumber   = cardHomeNumber
            CommonClass.sharedInstance.myCard.email        = cardEmail
            CommonClass.sharedInstance.myCard.address      = cardAddress
            
            cardPhoto.card          = CommonClass.sharedInstance.myCard
            cardName.card           = CommonClass.sharedInstance.myCard
            cardOccupation.card     = CommonClass.sharedInstance.myCard
            cardCompany.card        = CommonClass.sharedInstance.myCard
            cardMobileNumber.card   = CommonClass.sharedInstance.myCard
            cardHomeNumber.card     = CommonClass.sharedInstance.myCard
            cardEmail.card          = CommonClass.sharedInstance.myCard
            cardAddress.card        = CommonClass.sharedInstance.myCard
            
            
            let vc              = self.storyboard?.instantiateViewController(withIdentifier: "EditCardViewController") as! EditCardViewController
            vc.isEditCard       = false
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 6
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section==0{
            return 0.0
        }
        return 30.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view                = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.tableviewData.frame.size.width, height: 30))
        view.backgroundColor    = UIColor.clear
        
        let lblTitle = UILabel.init(frame: CGRect.init(x: 12, y: 0, width: self.tableviewData.frame.size.width-12-12, height: 30))
        lblTitle.textColor      = UIColor.gray
        lblTitle.text           = self.arraySectionNames.object(at: section) as? String
        
        view.addSubview(lblTitle)
        return view
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 2
        case 1:
            return 1
        case 2:
            return 1
        case 3:
            return 1
        case 4:
            return 3
        case 5:
            return 1
        default:
            break
        }
        return 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier1 = "switchCell"
        let identifier2 = "backgroundCell"
        let identifier3 = "inputCell"
        let identifier4 = "inputImageCell"
        
        var cell:CardCell!
        
        
        if indexPath.section == 0{
            if indexPath.row == 0{
                cell = tableView.dequeueReusableCell(withIdentifier: identifier1) as! CardCell
                cell.lblTitle.text      = "Photo"
                cell.lblTitle.textColor = UIColor.black
                cell.switchPhoto.isOn = self.isPhoto
            }else{
                cell = tableView.dequeueReusableCell(withIdentifier: identifier2) as! CardCell
                cell.lblTitle.text      = "Background"
                cell.lblTitle.textColor = CommonClass.sharedInstance.myCardBackgroundImage == nil ? UIColor.gray : UIColor.black
                cell.lblDetail.text     = CommonClass.sharedInstance.myCardBackgroundImage == nil ? "" : "Selected"
            }
        }else if indexPath.section == 1{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier3) as! CardCell
            cell.tfInformation.placeholder      = "Your Name"
            cell.tfInformation.text             = self.name
            cell.tfInformation.returnKeyType    = UIReturnKeyType.done
            cell.tfInformation.keyboardType     = UIKeyboardType.alphabet
            cell.tfInformation.autocapitalizationType = UITextAutocapitalizationType.words
            cell.tfInformation.tag              = 11
            cell.btnCheck.isSelected            = self.isName
        }else if indexPath.section == 2{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier3) as! CardCell
            cell.tfInformation.placeholder      = "Your Occupation"
            cell.tfInformation.text             = self.occupation
            cell.tfInformation.returnKeyType    = UIReturnKeyType.done
            cell.tfInformation.keyboardType     = UIKeyboardType.alphabet
            cell.tfInformation.autocapitalizationType = UITextAutocapitalizationType.words
            cell.tfInformation.tag              = 12
            cell.btnCheck.isSelected            = self.isOccupation
        }else if indexPath.section == 3{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier3) as! CardCell
            cell.tfInformation.placeholder      = "Company Name"
            cell.tfInformation.text             = self.companyName
            cell.tfInformation.returnKeyType    = UIReturnKeyType.done
            cell.tfInformation.keyboardType     = UIKeyboardType.alphabet
            cell.tfInformation.autocapitalizationType = UITextAutocapitalizationType.words
            cell.tfInformation.tag              = 13
            cell.btnCheck.isSelected            = self.isCompanyName
        }else if indexPath.section == 4{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier4) as! CardCell
            if indexPath.row == 0{
                cell.imageviewIcon.image = UIImage.init(named: "smartphone")
                cell.tfInformation.placeholder      = "Mobile Number"
                cell.tfInformation.text             = self.mobileNumber
                cell.tfInformation.returnKeyType    = UIReturnKeyType.done
                cell.tfInformation.keyboardType     = UIKeyboardType.phonePad
                cell.tfInformation.tag              = 14
                cell.btnCheck.isSelected            = self.isMobileNumber
            }else if indexPath.row == 1{
                cell.imageviewIcon.image = UIImage.init(named: "telephone")
                cell.tfInformation.placeholder      = "Home Number"
                cell.tfInformation.text             = self.telephoneNumber
                cell.tfInformation.returnKeyType    = UIReturnKeyType.done
                cell.tfInformation.keyboardType     = UIKeyboardType.phonePad
                cell.tfInformation.tag              = 15
                cell.btnCheck.isSelected            = self.isTelephoneNumber
            }else{
                cell.imageviewIcon.image = UIImage.init(named: "email")
                cell.tfInformation.placeholder      = "name@example.com"
                cell.tfInformation.text             = self.email
                cell.tfInformation.returnKeyType    = UIReturnKeyType.done
                cell.tfInformation.keyboardType     = UIKeyboardType.emailAddress
                cell.tfInformation.tag              = 16
                cell.btnCheck.isSelected            = self.isEmail
            }
        }else{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier3) as! CardCell
            cell.tfInformation.placeholder      = "Your Address"
            cell.tfInformation.text             = self.address
            cell.tfInformation.returnKeyType    = UIReturnKeyType.done
            cell.tfInformation.keyboardType     = UIKeyboardType.alphabet
            cell.tfInformation.autocapitalizationType = UITextAutocapitalizationType.words
            cell.tfInformation.tag              = 17
            cell.btnCheck.isSelected            = self.isAddress
        }
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let cell = tableView.cellForRow(at: indexPath) as! CardCell
//        cell.lblTitle.textColor = UIColor.black
        
        if indexPath.section == 0{
            if indexPath.row == 0{
                // Photos Tapped
            }else{
                // Background Tapped
                self.gotoSelectBackground()
            }
        }else if indexPath.section == 1{
            // Your Name
        }else if indexPath.section == 2{
            // Your Occupation
        }else if indexPath.section == 3{
            // Company Name
        }else if indexPath.section == 4{
            if indexPath.row == 0{
                // Mobile Number
            }else if indexPath.row == 1{
                // Telephone Number
            }else{
                // Email
            }
        }else{
            // Address
        }
    }
    
    //MARK:  TextField
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.tfSelected = textField
        let cell = textField.superview?.superview as! UITableViewCell
        let indexPath = self.tableviewData.indexPath(for: cell)
        
        self.tableviewBottomConstraint.constant = 165
        UIView.animate(withDuration: 0.25, animations: {
            self.view.layoutIfNeeded()
        }) { (isCompleted) in
            DispatchQueue.main.async {
                self.tableviewData.scrollToRow(at: indexPath!, at: UITableViewScrollPosition.top, animated: true)
            }
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var isUnderLength = true
        
        var requiredlength = 50
        if textField.tag == 14 || textField.tag == 15 || textField.tag == 16{
            requiredlength = 30
        }
        
        if textField.tag == 17 {
            requiredlength = 60
        }
        
        
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        if newLength <= requiredlength {
            isUnderLength = true
        }else{
            isUnderLength = false
        }
        
        var isAcceptable = true
        let ACCEPTABLE_CHARACTERS = "+#*0123456789"
        if textField.tag == 14 || textField.tag == 15  {
            let cs = CharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
            let filtered: String = (string.components(separatedBy: cs) as NSArray).componentsJoined(by: "")
            isAcceptable = (string == filtered) ? true : false
        }

        return (isUnderLength == true && isAcceptable == true) ? true : false
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        textField.resignFirstResponder()
        self.tfSelected  = nil
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
//        textField.resignFirstResponder()
//        let cell        = textField.superview?.superview as! CardCell
//        let indexPath   = self.tableviewData.indexPath(for: cell)
        switch textField.tag {
        case 11:
            print("Name Field Dismissed")
            self.name   = textField.text
            break
        case 12:
            print("Occupation Field Dismissed")
            self.occupation = textField.text
            break
        case 13:
            print("Company Field Dismissed")
            self.companyName = textField.text
            break
        case 14:
            print("Mobile Field Dismissed")
            self.mobileNumber = textField.text
            break
        case 15:
            print("Phone Field Dismissed")
            self.telephoneNumber = textField.text
            break
        case 16:
            print("Email Field Dismissed")
            self.email  = textField.text
            break
        case 17:
            print("Address Field Dismissed")
            self.address    = textField.text
            break
            
        default:
            break
        }
        
        self.tableviewBottomConstraint.constant = 0
        UIView.animate(withDuration: 0.25) {
            self.view.layoutIfNeeded()
            self.tableviewData.reloadData()
        }
    }
    
    
    //MARK:  ScrollView
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
