//
//  Address+CoreDataProperties.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 03/06/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


extension Address {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Address> {
        return NSFetchRequest<Address>(entityName: "Test")
    }
    

    @NSManaged public var card: Card?

    @NSManaged public var isOn: Bool
    @NSManaged public var text: String?
    
    @NSManaged public var color: String?
    @NSManaged public var fontSize: Int64
    @NSManaged public var fontName: String?
    
    @NSManaged public var isBold: Bool
    @NSManaged public var isItalic: Bool
    @NSManaged public var isUnderline: Bool
    
    @NSManaged public var centerX: Float
    @NSManaged public var centerY: Float

    @nonobjc public class func entityDescriptionForDefaultSettings(context:NSManagedObjectContext) -> Address {
        
        let obj           = NSEntityDescription.insertNewObject(forEntityName: "Address", into: context) as! Address
        obj.color         = "#000000"
        obj.fontSize      = UIScreen.main.bounds.height <= 568 ? 15 : 17
        obj.fontName      = "Helvetica"
        obj.isBold        = false
        obj.isItalic      = false
        obj.isUnderline   = false
        return obj
    }
    
}
