//
//  Photo+CoreDataProperties.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 24/05/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//
//

import Foundation
import CoreData


extension Photo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Photo> {
        return NSFetchRequest<Photo>(entityName: "Photo")
    }
    
    @nonobjc public class func entityDescription(context:NSManagedObjectContext) -> Photo {
        return NSEntityDescription.insertNewObject(forEntityName: "Photo", into: context) as! Photo
    }

    @NSManaged public var isOn: Bool
    @NSManaged public var imageName: String?
    @NSManaged public var card: Card?
    
    @NSManaged public var centerX: Float
    @NSManaged public var centerY: Float

}
