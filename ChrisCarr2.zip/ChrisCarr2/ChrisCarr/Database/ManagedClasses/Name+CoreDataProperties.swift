//
//  Name+CoreDataProperties.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 24/05/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


extension Name {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Name> {
        return NSFetchRequest<Name>(entityName: "Name")
    }
    

    @NSManaged public var card: Card?
    
    @NSManaged public var isOn: Bool
    @NSManaged public var text: String?
    
    @NSManaged public var color: String?
    @NSManaged public var fontSize: Int64
    @NSManaged public var fontName: String?
    
    @NSManaged public var isBold: Bool
    @NSManaged public var isItalic: Bool
    @NSManaged public var isUnderline: Bool
    
    @NSManaged public var centerX: Float
    @NSManaged public var centerY: Float
    
    @nonobjc public class func entityDescriptionForDefaultSettings(context:NSManagedObjectContext) -> Name {
        
        let obj           = NSEntityDescription.insertNewObject(forEntityName: "Name", into: context) as! Name
        obj.color         = "#000000"
        obj.fontSize      = UIScreen.main.bounds.height <= 568 ? 17 : 25
        obj.fontName      = "Helvetica"
        obj.isBold        = true
        obj.isItalic      = false
        obj.isUnderline   = false
        return obj
    }

}
