//
//  Occupation+CoreDataProperties.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 24/05/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


extension Occupation {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Occupation> {
        return NSFetchRequest<Occupation>(entityName: "Occupation")
    }

    @nonobjc public class func entityDescription(context:NSManagedObjectContext) -> Occupation {
        return NSEntityDescription.insertNewObject(forEntityName: "Occupation", into: context) as! Occupation
    }
    
    @NSManaged public var card: Card?
    
    @NSManaged public var isOn: Bool
    @NSManaged public var text: String?
    
    @NSManaged public var color: String?
    @NSManaged public var fontSize: Int64
    @NSManaged public var fontName: String?
    
    @NSManaged public var isBold: Bool
    @NSManaged public var isItalic: Bool
    @NSManaged public var isUnderline: Bool

    @NSManaged public var centerX: Float
    @NSManaged public var centerY: Float
    
    @nonobjc public class func entityDescriptionForDefaultSettings(context:NSManagedObjectContext) -> Occupation {
        
        let obj           = NSEntityDescription.insertNewObject(forEntityName: "Occupation", into: context) as! Occupation
        obj.color         = "#000000"
        obj.fontSize      = UIScreen.main.bounds.height <= 568 ? 13 : 15
        obj.fontName      = "Helvetica"
        obj.isBold        = false
        obj.isItalic      = false
        obj.isUnderline   = false
        return obj
    }
    
}
