//
//  TCViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 22/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit

class TCViewController: UIViewController {
    
    
    //MARK: Properties
    
    //MARK: Outlets
    
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        
    }
    
    
    //MARK:- Utility Methods
    
    
    //MARK:- Action Methods
    @IBAction func btnBack_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
