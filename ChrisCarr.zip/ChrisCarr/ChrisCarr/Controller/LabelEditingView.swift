//
//  LabelEditingView.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 28/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0


enum LabelType:Int {
    case Name
    case Occupation
    case Company
    case HomePhone
    case MobilePhone
    case Email
    case Address
}

enum PickerType:Int {
    case FontName
    case FontSize
}

protocol LabelEditingViewDelegate: class {
    func didTapOnCancel()
    func didTapOnSaveForLabel(type:LabelType)
    func didTapOnColorButton(color:UIColor, colorCode:String)
}

class LabelEditingView: UIView, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    
    
    //MARK: Properties
    var delegate:LabelEditingViewDelegate!
    var lblType:LabelType!
    
    
    var text:String!
    var color:UIColor!
    var colorCode:String!
    var fontSize:Int64!
    var fontName:String!
    var isBold:Bool!
    var isItalic:Bool!
    var isUnderline:Bool!
    
    var tfSelected:UITextField!
    var parentViewController:UIViewController!
    
    
    //MARK: Outlets
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var tableViewSettings: UITableView!
    @IBOutlet weak var btnSave: CustomButton!
    
    
    //MARK:- View Life Cycle Starts here...
    override func awakeFromNib() {
        super.awakeFromNib()
//        self.setupView()
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        self.collectionLabelProperties()
        self.registerTableviewCell()
        self.tableViewSettings.reloadData()
        
        let gesture = UITapGestureRecognizer.init(target: self, action: #selector(tableTapped(tap:)))
        self.addGestureRecognizer(gesture)
        self.isUserInteractionEnabled = true
    }
    
    func registerTableviewCell() {
        let nib = UINib(nibName: "TextSettingCell", bundle: nil)
        self.tableViewSettings.register(nib, forCellReuseIdentifier: "TextSettingCell")
    }
    
    
    //MARK:- Utility Methods
    func collectionLabelProperties() {
        switch self.lblType! {
        case .Name:
            self.text           = CommonClass.sharedInstance.myCard.name?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.name?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.name?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.name?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.name?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.name?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.name?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.name?.isUnderline
            break
        case .Occupation:
            self.text           = CommonClass.sharedInstance.myCard.occupation?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.occupation?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.occupation?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.occupation?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.occupation?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.occupation?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.occupation?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.occupation?.isUnderline
            break
        case .Company:
            self.text           = CommonClass.sharedInstance.myCard.company?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.company?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.company?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.company?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.company?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.company?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.company?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.company?.isUnderline
            break
        case .HomePhone:
            self.text           = CommonClass.sharedInstance.myCard.homeNumber?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.homeNumber?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.homeNumber?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.homeNumber?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.homeNumber?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.homeNumber?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.homeNumber?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.homeNumber?.isUnderline
            break
        case .MobilePhone:
            self.text           = CommonClass.sharedInstance.myCard.mobileNumber?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.mobileNumber?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.mobileNumber?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.mobileNumber?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.mobileNumber?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.mobileNumber?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.mobileNumber?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.mobileNumber?.isUnderline
            break
        case .Email:
            self.text           = CommonClass.sharedInstance.myCard.email?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.email?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.email?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.email?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.email?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.email?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.email?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.email?.isUnderline
            break
        case .Address:
            self.text           = CommonClass.sharedInstance.myCard.address?.text
            self.color          = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.address?.color)!)
            self.colorCode      = CommonClass.sharedInstance.myCard.address?.color
            self.fontSize       = CommonClass.sharedInstance.myCard.address?.fontSize
            self.fontName       = CommonClass.sharedInstance.myCard.address?.fontName
            self.isBold         = CommonClass.sharedInstance.myCard.address?.isBold
            self.isItalic       = CommonClass.sharedInstance.myCard.address?.isItalic
            self.isUnderline    = CommonClass.sharedInstance.myCard.address?.isUnderline
            break
            
        default:
            break
        }
        
        self.tableViewSettings.reloadData()
    }
    
    func updateLabelProperties() {
        switch self.lblType! {
        case .Name:
            CommonClass.sharedInstance.myCard.name?.text        = self.text
            CommonClass.sharedInstance.myCard.name?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.name?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.name?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.name?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.name?.isItalic 	= self.isItalic
            CommonClass.sharedInstance.myCard.name?.isUnderline = self.isUnderline
            break
        case .Occupation:
            CommonClass.sharedInstance.myCard.occupation?.text        = self.text
            CommonClass.sharedInstance.myCard.occupation?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.occupation?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.occupation?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.occupation?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.occupation?.isItalic     = self.isItalic
            CommonClass.sharedInstance.myCard.occupation?.isUnderline = self.isUnderline
            
            break
        case .Company:
            CommonClass.sharedInstance.myCard.company?.text        = self.text
            CommonClass.sharedInstance.myCard.company?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.company?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.company?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.company?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.company?.isItalic     = self.isItalic
            CommonClass.sharedInstance.myCard.company?.isUnderline = self.isUnderline

            break
        case .HomePhone:
            CommonClass.sharedInstance.myCard.homeNumber?.text        = self.text
            CommonClass.sharedInstance.myCard.homeNumber?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.homeNumber?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.homeNumber?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.homeNumber?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.homeNumber?.isItalic    = self.isItalic
            CommonClass.sharedInstance.myCard.homeNumber?.isUnderline = self.isUnderline
            
            break
        case .MobilePhone:
            CommonClass.sharedInstance.myCard.mobileNumber?.text        = self.text
            CommonClass.sharedInstance.myCard.mobileNumber?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.mobileNumber?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.mobileNumber?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.mobileNumber?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.mobileNumber?.isItalic    = self.isItalic
            CommonClass.sharedInstance.myCard.mobileNumber?.isUnderline = self.isUnderline
            
            break
        case .Email:
            CommonClass.sharedInstance.myCard.email?.text        = self.text
            CommonClass.sharedInstance.myCard.email?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.email?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.email?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.email?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.email?.isItalic    = self.isItalic
            CommonClass.sharedInstance.myCard.email?.isUnderline = self.isUnderline
            
            break
        case .Address:
            CommonClass.sharedInstance.myCard.address?.text        = self.text
            CommonClass.sharedInstance.myCard.address?.color       = self.colorCode
            CommonClass.sharedInstance.myCard.address?.fontSize    = self.fontSize
            CommonClass.sharedInstance.myCard.address?.fontName    = self.fontName
            CommonClass.sharedInstance.myCard.address?.isBold      = self.isBold
            CommonClass.sharedInstance.myCard.address?.isItalic    = self.isItalic
            CommonClass.sharedInstance.myCard.address?.isUnderline = self.isUnderline
            
            break
            
        default:
            break
        }
    }
    
    func updateLabelColor(color:UIColor) {
        self.color = color;
        self.colorCode = CommonClass.sharedInstance.getHexCodeFromColor(color: color)
        self.tableViewSettings.reloadData()
    }
    
    func showPicker(type:PickerType) {
        
        var title = ""
        var values:[String]!  = []
        
        switch type {
        case .FontName:
            title = "Select Font"
            values    = UIFont.familyNames
            values    = values.sorted(by: <)
            break
            
        default:
            title = "Select Font Size"
            for  i in 8...20{
                values.append(String.init(format: "%dpt", i))
            }
//            let frameSizes: [CGFloat] = (8...20).map { CGFloat($0) }
//            values = frameSizes.map {Int($0).description}
            break
        }
        
        ActionSheetStringPicker.show(withTitle: title, rows: values, initialSelection: 0, doneBlock: { (picker, index, value) in
            switch type {
            case .FontName:
                self.fontName = value as! String
                break
                
            default:
                let fontSize = (value as! String).replacingOccurrences(of: "pt", with: "")
                self.fontSize = Int64(fontSize)
                break
            }
            self.tableViewSettings.reloadData()
        }, cancel: { (picker) in
        }, origin: self)
        
    }
    
    @objc func tableTapped(tap:UITapGestureRecognizer) {
        let location = tap.location(in: self.tableViewSettings)
        let path = self.tableViewSettings.indexPathForRow(at: location)
        if let indexPathForRow = path {
            if indexPathForRow != IndexPath.init(row: 0, section: 0){
                self.dismissKeyboard()
            }
            self.rowSelectedForIndexPath(indexPath: indexPathForRow)
        } else {
            self.dismissKeyboard()
        }
    }
    
    
    func dismissKeyboard() {
        if tfSelected != nil{
            self.tfSelected.resignFirstResponder()
        }
    }
    
    //MARK:- Action Methods
    @IBAction func btnCancel_Action(_ sender: UIButton) {
        if self.delegate != nil {
            self.delegate.didTapOnCancel()
        }
    }
    
    @IBAction func btnSave_Action(_ sender: UIButton) {
        if self.delegate != nil {
            self.updateLabelProperties()
            self.delegate.didTapOnSaveForLabel(type: self.lblType)
        }
    }
    
    @objc func btnColor_Action(_ sender: UIButton) {
        if self.delegate != nil {
            self.delegate.didTapOnColorButton(color: self.color, colorCode: self.colorCode)
        }
    }
    
    
    @objc func switchBold_Action(_ sender: UISwitch) {
        self.isBold      = sender.isOn
    }
    @objc func switchItalic_Action(_ sender: UISwitch) {
        self.isItalic    = sender.isOn
    }
    @objc func switchUnderline_Action(_ sender: UISwitch) {
        self.isUnderline = sender.isOn
    }
    
    
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.tableViewSettings.frame.size.width, height: 30.0))
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var numberOfRows = 0
        
        switch section {
        case 0:
            numberOfRows = 2
            break
        case 1:
            numberOfRows = 2
            break
        case 2:
            numberOfRows = 3
            break
        default:
            break
        }
        return numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier  = "TextSettingCell"
        let cell        = tableView.dequeueReusableCell(withIdentifier: identifier) as! TextSettingCell
        
        switch indexPath.section {
        case 0:
            cell.optionSwitch.isHidden  = true
            cell.textField.isHidden     = true
            cell.btnColor.isHidden      = true
            cell.detailTextLabel?.text  = ""
            
            if indexPath.row == 0{
                cell.textField.isHidden         = false
                
                cell.textLabel?.text            = "Name"
                cell.textField.text             = self.text
                cell.textField.delegate         = self
                cell.textField.returnKeyType    = UIReturnKeyType.done
                
                if self.lblType == .MobilePhone || self.lblType == .HomePhone {
                    cell.textField.keyboardType = UIKeyboardType.phonePad
                }
                
                if self.lblType == .Email{
                    cell.textField.keyboardType = UIKeyboardType.emailAddress
                }
            }
            if indexPath.row == 1 {
                cell.btnColor.isHidden      = false
                
                cell.textLabel?.text        = "Text Color"
                cell.btnColor.backgroundColor = self.color
                cell.btnColor.addTarget(self, action: #selector(self.btnColor_Action(_:)), for: .touchUpInside)
            }
            break
        case 1:
            cell.textField.isHidden     = true
            cell.optionSwitch.isHidden  = true
            cell.btnColor.isHidden      = true
            if indexPath.row == 0{
                cell.textLabel?.text        = "Font Size"
                cell.detailTextLabel?.text  = String.init(format: "%dpt", self.fontSize)
            }
            if indexPath.row == 1{
                cell.textLabel?.text        = "Font"
                cell.detailTextLabel?.text  = self.fontName
            }
            break
        case 2:
            cell.textField.isHidden     = true
            cell.btnColor.isHidden      = true
            cell.optionSwitch.isHidden  = false
            cell.detailTextLabel?.text  = ""
            
            if indexPath.row == 0{
                cell.textLabel?.text        = "Bold"
                cell.optionSwitch.isOn      = self.isBold
                cell.optionSwitch.addTarget(self, action: #selector(switchBold_Action(_:)), for: UIControlEvents.valueChanged)
            }
            if indexPath.row == 1{
                cell.textLabel?.text        = "Italic"
                cell.optionSwitch.isOn      = self.isItalic
                cell.optionSwitch.addTarget(self, action: #selector(switchItalic_Action(_:)), for: UIControlEvents.valueChanged)
            }
            if indexPath.row == 2{
                cell.textLabel?.text        = "Underline"
                cell.optionSwitch.isOn      = self.isUnderline
                cell.optionSwitch.addTarget(self, action: #selector(switchUnderline_Action(_:)), for: UIControlEvents.valueChanged)
            }
            
            break
        default:
            break
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.rowSelectedForIndexPath(indexPath: indexPath)
    }
    
    func rowSelectedForIndexPath(indexPath:IndexPath) {
        if indexPath.section == 1 && indexPath.row == 0{
            self.showPicker(type:PickerType.FontSize)
        }else if indexPath.section == 1 && indexPath.row == 1{
            self.showPicker(type:PickerType.FontName)
        }
    }
    
    //MARK:  TextField
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.tfSelected = textField
        self.btnCancel.isEnabled                        = false
        self.btnSave.isEnabled                          = false
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        var isUnderLength = true
        
        var requiredlength = 50
        if self.lblType == .MobilePhone || self.lblType == .HomePhone || self.lblType == .Email{
            requiredlength = 30
        }
        
        if self.lblType == .Address {
            requiredlength = 60
        }
        
        
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        if newLength <= requiredlength {
            isUnderLength = true
        }else{
            isUnderLength = false
        }
        
        var isAcceptable = true
        let ACCEPTABLE_CHARACTERS = "+#*0123456789"
        if self.lblType == .MobilePhone || self.lblType == .HomePhone  {
            let cs = CharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
            let filtered: String = (string.components(separatedBy: cs) as NSArray).componentsJoined(by: "")
            isAcceptable = (string == filtered) ? true : false
        }
        
        return (isUnderLength == true && isAcceptable == true) ? true : false
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnCancel.isEnabled    = true
        self.btnSave.isEnabled      = true
        self.tfSelected             = nil
        
        if self.lblType == .Email && !(CommonClass.sharedInstance.isValidEmail(testStr: textField.text!)){
            CommonClass.sharedInstance.showAlertView(vc: self.parentViewController, title: "Invalid Email", message: "Please enter valid email address", buttons: ["Ok"]) { (buttonText, Avc) in
                
            }
            textField.text      = self.text
        }else{
            self.text                   = textField.text
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        var returnType  = false
        let tfText      = textField.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        if (tfText?.isEmpty)! {
            returnType  = false
        }else{
            returnType  = true
        }
        
        textField.resignFirstResponder()
        return returnType
    }
    
    
    //MARK:  ScrollView
    
    
    //MARK:- View Life Cycle Ends here...
    
    
}

