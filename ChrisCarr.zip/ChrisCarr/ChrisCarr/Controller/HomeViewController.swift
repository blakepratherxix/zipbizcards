//
//  HomeViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 11/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import DeviceCheck


class HomeViewController: UIViewController, TGLParallaxCarouselDelegate,TGLParallaxCarouselDatasource {
    
    
    //MARK: Properties
    var arrayCards:NSMutableArray? = NSMutableArray.init()
    
    
    //MARK: Outlets
    
    @IBOutlet weak var carouselView: TGLParallaxCarousel!
    @IBOutlet weak var btnFirstMessage: UIButton!
    @IBOutlet weak var btnPrint: UIButton!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnShare: UIButton!
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.carouselView.isHidden      = true
        self.btnFirstMessage.isHidden   = true
        self.btnPrint.isHidden          = true
        self.btnEdit.isHidden           = true
        self.btnShare.isHidden          = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.setupView()
        self.setupCards()
    }
    
    //MARK:- View Setup Methods
    
    func setupView() {
        
        self.btnFirstMessage.titleLabel?.textAlignment = NSTextAlignment.center

        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context     = appDelegate.persistentContainer.viewContext
        
        Card.getAllCards(context: context) { (cardsArray) in
            
            self.arrayCards = NSMutableArray.init(array: cardsArray.reversed())
            if (Double((self.arrayCards?.count)!) > 0 ){
                self.setupViewForFistCard(isFirstCard: false)
                self.carouselView.reloadData()
            }else{
                self.setupViewForFistCard(isFirstCard: true)
            }
        }
        
    }
    
    
    //MARK:- Utility Methods
    func setupCards() {
        if self.carouselView.delegate == nil {
            self.carouselView.delegate      = self
            self.carouselView.datasource    = self
            self.carouselView.itemMargin    = 10
        }
    }
    func setupViewForFistCard(isFirstCard:Bool) {
        self.carouselView.isHidden      = isFirstCard
        self.btnFirstMessage.isHidden   = !isFirstCard
        self.btnPrint.isHidden          = isFirstCard
        self.btnEdit.isHidden           = isFirstCard
        self.btnShare.isHidden          = isFirstCard
    }
    
    //MARK:- Action Methods
    
    @IBAction func btnSettings_Action(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController")
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func btnAddCard_Action(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddNewCardViewController")
        self.present(vc!, animated: true, completion: nil)
    }
    
    
    @IBAction func btnPrint_Action(_ sender: UIButton) {
        let vc          = self.storyboard?.instantiateViewController(withIdentifier: "PrintOptionViewController") as! PrintOptionViewController
        vc.selectedCard = self.arrayCards?.object(at:self.carouselView.selectedIndex) as! Card
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnEdit_Action(_ sender: UIButton) {
        CommonClass.sharedInstance.myCard = self.arrayCards?.object(at:self.carouselView.selectedIndex) as! Card
        let vc          = self.storyboard?.instantiateViewController(withIdentifier: "EditCardViewController") as! EditCardViewController
        vc.isEditCard   = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnShare_Action(_ sender: UIButton) {
        let cardItem = self.arrayCards?.object(at:self.carouselView.selectedIndex) as! Card
        
        let shareText  = cardItem.name?.text
        let shareImage = CommonClass.sharedInstance.getImageFrom(isBackgroundImage: true, cacheMemory: false, imageName: cardItem.cardImageName!)
        let vc = UIActivityViewController.init(activityItems: [shareText!,shareImage], applicationActivities: [])
        self.present(vc, animated: true, completion: nil)
    }
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    //MARK: TGLParallaxCarousel datasource
    
    func numberOfItemsInCarousel(carousel: TGLParallaxCarousel) ->Int {
        return (self.arrayCards?.count)!
    }
    
    func viewForItemAtIndex(index: Int, carousel: TGLParallaxCarousel) -> TGLParallaxCarouselItem {
        let item                    = TGLParallaxCarouselItem.init(frame: CGRect.init(x: 0, y: 0, width: 300, height: 150))
        item.backgroundColor        = UIColor.white
        item.layer.cornerRadius     = 5.0
        item.layer.shadowColor      = UIColor.lightGray.cgColor
        item.layer.shadowOpacity    = 0.5
        item.layer.shadowRadius     = 4.0
        item.layer.shadowOffset     = CGSize.init(width: 0.0, height: 0.0)
        item.clipsToBounds          = true

        let cardItem = self.arrayCards?.object(at:index) as! Card
        
        
        let imageV                  = UIImageView.init(frame: item.frame)
        imageV.image                = CommonClass.sharedInstance.getImageFrom(isBackgroundImage: true, cacheMemory: false, imageName: cardItem.cardImageName!)
        imageV.autoresizingMask     = [.flexibleHeight, .flexibleWidth]
        item.addSubview(imageV)
        
        return item 
    }
    
    func didMovetoPageAtIndex(index: Int) {
        print("Did move to index \(index)")
    }
    
    func didTapOnItemAtIndex(index: Int, carousel: TGLParallaxCarousel) {
        
    }
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
