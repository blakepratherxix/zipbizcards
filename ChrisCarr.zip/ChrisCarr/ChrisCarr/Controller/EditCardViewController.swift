//
//  EditCardViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 19/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import Device
import EFColorPicker
import KRProgressHUD
import CropViewController


class EditCardViewController: UIViewController, LabelEditingViewDelegate, EFColorSelectionViewControllerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, CropViewControllerDelegate {
    
    
    //MARK: Properties
    var isLineColor:Bool! = false
    var isEditCard:Bool! = false
    var colorSelectionController:EFColorSelectionViewController!
    
    // for track the gesture distance
    var arePositionsSaved = false
    
    
    var lblEditingView:LabelEditingView!
    
    //MARK: Outlets
    
    @IBOutlet weak var lblNavBarTitle: UILabel!
    @IBOutlet weak var btnIdea: UIButton!
    
    @IBOutlet weak var cardView: CustomView!
    @IBOutlet weak var btnSelectLineColor: UIButton!

    @IBOutlet weak var imageViewCardBG: UIImageView!
    @IBOutlet weak var btnAddBackground: UIButton!
    
    @IBOutlet weak var imageviewCardHolder: UIImageView!
    @IBOutlet weak var btnEditImage: UIButton!
    
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnEditName: UIButton!
    @IBOutlet weak var lblNameTopConstraint: NSLayoutConstraint!
    
    
    
    @IBOutlet weak var lblOccupation: UILabel!
    @IBOutlet weak var btnEditOccupation: UIButton!
    @IBOutlet weak var lblOccupationTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var lblCompany: UILabel!
    @IBOutlet weak var btnEditCompany: UIButton!
    @IBOutlet weak var lblCompanyTopConstraint: NSLayoutConstraint!
    
    
    @IBOutlet weak var imageViewMobile: UIImageView!
    @IBOutlet weak var lblMobileNumber: UILabel!
    @IBOutlet weak var btnEditMobileNumber: UIButton!
    @IBOutlet weak var lblMobileNumberBottomConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var imageViewTelephone: UIImageView!
    @IBOutlet weak var lblTelephoneNumber: UILabel!
    @IBOutlet weak var btnEditTelephoneNumber: UIButton!
    @IBOutlet weak var lblTelephoneNumberBottomConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var btnEditEmail: UIButton!
    
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var btnEditAddress: UIButton!
    
    
    
    
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.setupCardData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if (self.isEditCard || self.arePositionsSaved){
            self.setupPositions()
        }
        self.savePositions()
    }
    
    func setupView() {
        self.lblNavBarTitle.text    = self.isEditCard ? "Edit Card" : "Add Card"
        self.btnIdea.isHidden       = self.isEditCard
        self.setupEditButtons()
        self.setupGestures()
        
        if (!self.isEditCard){
            self.imageviewCardHolder.image = UIImage.init(named: "avatar-circle")
            self.btnEditImage.titleLabel?.text  = "ADD"
        }
        
        if UIScreen.main.bounds.width <= 568 {
            self.lblNameTopConstraint.constant          	= self.lblNameTopConstraint.constant - 10.0
            self.lblOccupationTopConstraint.constant    	= self.lblOccupationTopConstraint.constant - 10.0
            self.lblCompanyTopConstraint.constant           = self.lblCompanyTopConstraint.constant - 10.0
            self.lblMobileNumberBottomConstraint.constant   = self.lblMobileNumberBottomConstraint.constant - 15.0
            self.lblTelephoneNumberBottomConstraint.constant   = self.lblTelephoneNumberBottomConstraint.constant - 15.0
        }
    }
    
    
    func setupEditButtons() {
        switch Device.size() {
        case .screen4Inch:do {
            self.btnEditImage.titleLabel?.font        = UIFont.systemFont(ofSize: 10.0)
            self.btnAddBackground.titleLabel?.font    = UIFont.systemFont(ofSize: 10.0)
            self.btnSelectLineColor.titleLabel?.font  = UIFont.systemFont(ofSize: 10.0)
            }
        case .screen4_7Inch:do {
            }
        case .screen5_5Inch:do {
            }
            
        default: print("default")
        }
    }
    
    
    func setupGestures() {
        let gesture1 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblName.addGestureRecognizer(gesture1)
        
        let gesture2 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblOccupation.addGestureRecognizer(gesture2)
        
        let gesture3 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblCompany.addGestureRecognizer(gesture3)
        
        let gesture4 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblTelephoneNumber.addGestureRecognizer(gesture4)
        
        let gesture5 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblMobileNumber.addGestureRecognizer(gesture5)
        
        let gesture6 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblEmail.addGestureRecognizer(gesture6)
        
        let gesture7 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.lblAddress.addGestureRecognizer(gesture7)
        
        let gesture8 = UIPanGestureRecognizer(target: self, action: #selector(wasDragged(gesture:)))
        self.imageviewCardHolder.addGestureRecognizer(gesture8)
    }
   
    
    //MARK:- Utility Methods
    func setupCardData() {
        
        
        if (self.isEditCard && CommonClass.sharedInstance.myCardBackgroundImage == nil && CommonClass.sharedInstance.myCard.backgroundImageName?.count != 0) {
            CommonClass.sharedInstance.myCardBackgroundImage      = CommonClass.sharedInstance.getImageFrom(isBackgroundImage: true, cacheMemory: false, imageName: CommonClass.sharedInstance.myCard.backgroundImageName!)
        }
        
        if !(CommonClass.sharedInstance.myCard.photo?.isOn)!{
            self.imageviewCardHolder.isHidden   = true
            self.btnEditImage.isHidden          = true
        }
        if (self.isEditCard && CommonClass.sharedInstance.myCardUserImage == nil && (CommonClass.sharedInstance.myCard.photo?.isOn)! && CommonClass.sharedInstance.myCard.photo?.imageName?.count != 0) {
            let userImage = CommonClass.sharedInstance.getImageFrom(isBackgroundImage: false, cacheMemory: false, imageName: (CommonClass.sharedInstance.myCard.photo?.imageName)!)
            CommonClass.sharedInstance.myCardUserImage  = userImage
        }
        
        if CommonClass.sharedInstance.myCardBackgroundImage != nil {
            self.imageViewCardBG.image      = CommonClass.sharedInstance.myCardBackgroundImage
        }
        
        if CommonClass.sharedInstance.myCardUserImage != nil {
            self.imageviewCardHolder.image  = CommonClass.sharedInstance.myCardUserImage
        }
        
        
        
        self.cardView.layer.borderWidth = 1.0
        self.cardView.layer.borderColor = CommonClass.sharedInstance.colorFrom(hex: CommonClass.sharedInstance.myCard.lineColor!).cgColor
        
        self.setupName()
        self.setupOccupation()
        self.setupCompany()
        self.setupHomeNumber()
        self.setupMobileNumber()
        self.setupEmail()
        self.setupAddress()
    }
    
    
    func showLabelEditingViewFor(type:LabelType) {
        self.lblEditingView                         = Bundle.main.loadNibNamed("LabelEditingView", owner: self, options: nil)?.first as! LabelEditingView
        self.lblEditingView.frame                   = CGRect.init(x: 0, y: 0, width:self.view.frame.size.width, height: self.view.frame.size.height)
        self.lblEditingView.delegate                = self
        self.lblEditingView.lblType                 = type
        self.lblEditingView.parentViewController    = self
        self.lblEditingView.setupView()
        self.view.addSubview(lblEditingView)
    }
    
    func gotoBackgroundSelectionView() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SelectBGViewController") as! SelectBGViewController
        vc.comingFromCardView   = true
        vc.isCacheMemory        = !self.isEditCard
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showColorPickerController(color:UIColor) {
        self.colorSelectionController = EFColorSelectionViewController()
        let navCtrl = UINavigationController(rootViewController: colorSelectionController)
        navCtrl.navigationBar.backgroundColor = UIColor.white
        navCtrl.navigationBar.isTranslucent = false
        navCtrl.popoverPresentationController?.delegate = (self as? UIPopoverPresentationControllerDelegate)
//        navCtrl.popoverPresentationController?.sourceView = sender
//        navCtrl.popoverPresentationController?.sourceRect = sender.bounds
        navCtrl.preferredContentSize = colorSelectionController.view.systemLayoutSizeFitting(
            UILayoutFittingCompressedSize
        )
        
        self.colorSelectionController.delegate = (self as EFColorSelectionViewControllerDelegate)
        self.colorSelectionController.color = color
        
        let btnDone:UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.dismissColorPicker))
        self.colorSelectionController.navigationItem.rightBarButtonItem = btnDone
        self.present(navCtrl, animated: true, completion: nil)
    }
    
    @objc func dismissColorPicker() {
        self.colorSelectionController.dismiss(animated: true, completion: nil)
    }
    
    func isCardDataValid() -> Bool{
        return true
    }
    
    func hideButton(option:Bool) {
        self.btnAddBackground.isHidden          = option
        self.btnEditName.isHidden               = option
        self.btnEditImage.isHidden              = option
        self.btnEditOccupation.isHidden         = option
        self.btnEditCompany.isHidden            = option
        self.btnSelectLineColor.isHidden        = option
        self.btnEditTelephoneNumber.isHidden    = option
        self.btnEditMobileNumber.isHidden       = option
        self.btnEditEmail.isHidden              = option
        self.btnEditAddress.isHidden            = option
    }
    
    func setupPositions() {
        UIView.animate(withDuration: 0.25) {
            self.imageviewCardHolder.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.photo?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.photo?.centerY)!))
            self.btnEditImage.frame = CGRect.init(x: self.imageviewCardHolder.frame.origin.x, y: self.imageviewCardHolder.frame.origin.y + (self.imageviewCardHolder.frame.size.height - self.btnEditImage.frame.size.height) , width: self.btnEditImage.frame.size.width, height: self.btnEditImage.frame.size.height)
            
            self.lblName.center     = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.name?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.name?.centerY)!))
            self.btnEditName.center = CGPoint.init(x: self.lblName.frame.origin.x, y: self.lblName.center.y)
            
            self.lblOccupation.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.occupation?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.occupation?.centerY)!))
            self.btnEditOccupation.center = CGPoint.init(x: self.lblOccupation.frame.origin.x + self.lblOccupation.frame.size.width, y: self.lblOccupation.center.y)
            
            self.lblCompany.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.company?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.company?.centerY)!))
            self.btnEditCompany.center = CGPoint.init(x: self.lblCompany.frame.origin.x + self.lblCompany.frame.size.width, y: self.lblCompany.center.y)
            
            self.lblTelephoneNumber.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.homeNumber?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.homeNumber?.centerY)!))
            self.imageViewTelephone.center      = CGPoint.init(x: self.lblTelephoneNumber.frame.origin.x - 10 - (self.imageViewTelephone.frame.size.width/2), y: self.lblTelephoneNumber.center.y)
            self.btnEditTelephoneNumber.center  = CGPoint.init(x: self.lblTelephoneNumber.frame.origin.x + self.lblTelephoneNumber.frame.size.width, y: self.lblTelephoneNumber.center.y)
            
            self.lblMobileNumber.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.mobileNumber?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.mobileNumber?.centerY)!))
            self.imageViewMobile.center      = CGPoint.init(x: self.lblMobileNumber.frame.origin.x - 10 - (self.imageViewMobile.frame.size.width/2), y: self.lblMobileNumber.center.y)
            self.btnEditMobileNumber.center  = CGPoint.init(x: self.lblMobileNumber.frame.origin.x + self.lblMobileNumber.frame.size.width, y: self.lblMobileNumber.center.y)
            
            self.lblEmail.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.email?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.email?.centerY)!))
            self.btnEditEmail.center = CGPoint.init(x: self.lblEmail.frame.origin.x + self.lblEmail.frame.size.width, y: self.lblEmail.center.y)
            
            self.lblAddress.center = CGPoint.init(x: CGFloat((CommonClass.sharedInstance.myCard.address?.centerX)!) , y: CGFloat((CommonClass.sharedInstance.myCard.address?.centerY)!))
            self.btnEditAddress.center = CGPoint.init(x: self.lblAddress.frame.origin.x + self.lblAddress.frame.size.width, y: self.lblAddress.center.y)
            
        }
    }
    
    func savePositions() {
        CommonClass.sharedInstance.myCard.photo?.centerX        = Float.init(self.imageviewCardHolder.center.x)
        CommonClass.sharedInstance.myCard.photo?.centerY        = Float.init(self.imageviewCardHolder.center.y)
        
        CommonClass.sharedInstance.myCard.name?.centerX         = Float.init(self.lblName.center.x)
        CommonClass.sharedInstance.myCard.name?.centerY         = Float.init(self.lblName.center.y)
        
        CommonClass.sharedInstance.myCard.occupation?.centerX   = Float.init(self.lblOccupation.center.x)
        CommonClass.sharedInstance.myCard.occupation?.centerY   = Float.init(self.lblOccupation.center.y)
        
        CommonClass.sharedInstance.myCard.company?.centerX      = Float.init(self.lblCompany.center.x)
        CommonClass.sharedInstance.myCard.company?.centerY      = Float.init(self.lblCompany.center.y)
        
        CommonClass.sharedInstance.myCard.homeNumber?.centerX   = Float.init(self.lblTelephoneNumber.center.x)
        CommonClass.sharedInstance.myCard.homeNumber?.centerY   = Float.init(self.lblTelephoneNumber.center.y)
        
        CommonClass.sharedInstance.myCard.mobileNumber?.centerX = Float.init(self.lblMobileNumber.center.x)
        CommonClass.sharedInstance.myCard.mobileNumber?.centerY = Float.init(self.lblMobileNumber.center.y)
        
        CommonClass.sharedInstance.myCard.email?.centerX        = Float.init(self.lblEmail.center.x)
        CommonClass.sharedInstance.myCard.email?.centerY        = Float.init(self.lblEmail.center.y)
        
        CommonClass.sharedInstance.myCard.address?.centerX      = Float.init(self.lblAddress.center.x)
        CommonClass.sharedInstance.myCard.address?.centerY      = Float.init(self.lblAddress.center.y)
        
        self.arePositionsSaved = true
        
    }
    
    
    //MARK:- Setup Label with Properties
    
    func setupName() {
        
        if !(CommonClass.sharedInstance.myCard.name?.isOn)! {
            self.lblName.isHidden       = true
            self.btnEditName.isHidden   = true
        }
        
        // TEXT
        self.lblName.text       = CommonClass.sharedInstance.myCard.name?.text
        
        // TEXT COLOR
        self.lblName.textColor  = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.name?.color)!)
        
        // FONT
        let fontName            = (CommonClass.sharedInstance.myCard.name?.fontName)!
        let fontSize            = CGFloat((CommonClass.sharedInstance.myCard.name?.fontSize)!)
        self.lblName.font       = UIFont.init(name:fontName , size:fontSize)
        
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.name?.isBold)! {
            let currentFont     = self.lblName.font
            self.lblName.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.name?.isItalic)! {
            let currentFont     = self.lblName.font
            self.lblName.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.name?.isBold)! && (CommonClass.sharedInstance.myCard.name?.isItalic)!) {
            let currentFont     = self.lblName.font
            self.lblName.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblName.underline(isUnderLine: (CommonClass.sharedInstance.myCard.name?.isUnderline)!)
        
    }
    
    func setupOccupation() {
        
        if !(CommonClass.sharedInstance.myCard.occupation?.isOn)! {
            self.lblOccupation.isHidden     = true
            self.btnEditOccupation.isHidden = true
        }
        
        self.lblOccupation.text = CommonClass.sharedInstance.myCard.occupation?.text
        
        self.lblOccupation.textColor  = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.occupation?.color)!)
        let fontName            = (CommonClass.sharedInstance.myCard.occupation?.fontName)!
        let fontSize            = CGFloat((CommonClass.sharedInstance.myCard.occupation?.fontSize)!)
        self.lblOccupation.font = UIFont.init(name:fontName , size:fontSize)
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.occupation?.isBold)! {
            let currentFont     = self.lblOccupation.font
            self.lblOccupation.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.occupation?.isItalic)! {
            let currentFont     = self.lblOccupation.font
            self.lblOccupation.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.occupation?.isBold)! && (CommonClass.sharedInstance.myCard.occupation?.isItalic)!) {
            let currentFont     = self.lblOccupation.font
            self.lblOccupation.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblOccupation.underline(isUnderLine: (CommonClass.sharedInstance.myCard.occupation?.isUnderline)!)
    }
    
    func setupCompany() {
        
        if !(CommonClass.sharedInstance.myCard.company?.isOn)! {
            self.lblCompany.isHidden        = true
            self.btnEditCompany.isHidden    = true
        }
        
        self.lblCompany.text = CommonClass.sharedInstance.myCard.company?.text
        
        self.lblCompany.textColor  = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.company?.color)!)
        let fontName            = (CommonClass.sharedInstance.myCard.company?.fontName)!
        let fontSize            = CGFloat((CommonClass.sharedInstance.myCard.company?.fontSize)!)
        self.lblCompany.font = UIFont.init(name:fontName , size:fontSize)
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.company?.isBold)! {
            let currentFont     = self.lblCompany.font
            self.lblCompany.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.company?.isItalic)! {
            let currentFont     = self.lblCompany.font
            self.lblCompany.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.company?.isBold)! && (CommonClass.sharedInstance.myCard.company?.isItalic)!) {
            let currentFont     = self.lblCompany.font
            self.lblCompany.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblCompany.underline(isUnderLine: (CommonClass.sharedInstance.myCard.company?.isUnderline)!)
    }
    
    func setupHomeNumber() {
        
        if !(CommonClass.sharedInstance.myCard.homeNumber?.isOn)! {
            self.imageViewTelephone.isHidden    	= true
            self.lblTelephoneNumber.isHidden 	    = true
            self.btnEditTelephoneNumber.isHidden    = true
        }
        
        self.lblTelephoneNumber.text    = CommonClass.sharedInstance.myCard.homeNumber?.text
        
        let myImage                         = UIImage.init(named: "telephone.png")
        let tintableImage                   = myImage?.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
        self.imageViewTelephone.image       = tintableImage
        self.imageViewTelephone.tintColor   = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.homeNumber?.color)!)
        
        self.lblTelephoneNumber.textColor   = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.homeNumber?.color)!)
        let fontName                    = (CommonClass.sharedInstance.myCard.homeNumber?.fontName)!
        let fontSize            	    = CGFloat((CommonClass.sharedInstance.myCard.homeNumber?.fontSize)!)
        self.lblTelephoneNumber.font 	= UIFont.init(name:fontName , size:fontSize)
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.homeNumber?.isBold)! {
            let currentFont     = self.lblTelephoneNumber.font
            self.lblTelephoneNumber.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.homeNumber?.isItalic)! {
            let currentFont     = self.lblTelephoneNumber.font
            self.lblTelephoneNumber.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.homeNumber?.isBold)! && (CommonClass.sharedInstance.myCard.homeNumber?.isItalic)!) {
            let currentFont     = self.lblTelephoneNumber.font
            self.lblTelephoneNumber.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblTelephoneNumber.underline(isUnderLine: (CommonClass.sharedInstance.myCard.homeNumber?.isUnderline)!)
    }
    
    func setupMobileNumber() {
        
        if !(CommonClass.sharedInstance.myCard.mobileNumber?.isOn)! {
            self.imageViewMobile.isHidden        = true
            self.lblMobileNumber.isHidden        = true
            self.btnEditMobileNumber.isHidden    = true
        }
        
        self.lblMobileNumber.text       = CommonClass.sharedInstance.myCard.mobileNumber?.text
        
        let myImage                      = UIImage.init(named: "smartphone.png")
        let tintableImage                = myImage?.withRenderingMode(UIImageRenderingMode.alwaysTemplate)
        self.imageViewMobile.image       = tintableImage
        self.imageViewMobile.tintColor   = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.mobileNumber?.color)!)
        
        self.lblMobileNumber.textColor  = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.mobileNumber?.color)!)
        let fontName                = (CommonClass.sharedInstance.myCard.mobileNumber?.fontName)!
        let fontSize                = CGFloat((CommonClass.sharedInstance.myCard.mobileNumber?.fontSize)!)
        self.lblMobileNumber.font   = UIFont.init(name:fontName , size:fontSize)
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.mobileNumber?.isBold)! {
            let currentFont     = self.lblMobileNumber.font
            self.lblMobileNumber.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.mobileNumber?.isItalic)! {
            let currentFont     = self.lblMobileNumber.font
            self.lblMobileNumber.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.mobileNumber?.isBold)! && (CommonClass.sharedInstance.myCard.mobileNumber?.isItalic)!) {
            let currentFont     = self.lblMobileNumber.font
            self.lblMobileNumber.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblMobileNumber.underline(isUnderLine: (CommonClass.sharedInstance.myCard.mobileNumber?.isUnderline)!)
    }
    
    func setupEmail() {
        
        if !(CommonClass.sharedInstance.myCard.email?.isOn)! {
            self.lblEmail.isHidden        = true
            self.btnEditEmail.isHidden    = true
        }
        
        self.lblEmail.text  = CommonClass.sharedInstance.myCard.email?.text
        
        self.lblEmail.textColor  = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.email?.color)!)
        let fontName        = (CommonClass.sharedInstance.myCard.email?.fontName)!
        let fontSize        = CGFloat((CommonClass.sharedInstance.myCard.email?.fontSize)!)
        self.lblEmail.font  = UIFont.init(name:fontName , size:fontSize)
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.email?.isBold)! {
            let currentFont     = self.lblEmail.font
            self.lblEmail.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.email?.isItalic)! {
            let currentFont     = self.lblEmail.font
            self.lblEmail.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.email?.isBold)! && (CommonClass.sharedInstance.myCard.email?.isItalic)!) {
            let currentFont     = self.lblEmail.font
            self.lblEmail.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblEmail.underline(isUnderLine: (CommonClass.sharedInstance.myCard.email?.isUnderline)!)
    }
    
    func setupAddress() {
        
        if !(CommonClass.sharedInstance.myCard.address?.isOn)! {
            self.lblAddress.isHidden        = true
            self.btnEditAddress.isHidden    = true
        }
        
        self.lblAddress.text    = CommonClass.sharedInstance.myCard.address?.text
        
        self.lblAddress.textColor  = CommonClass.sharedInstance.colorFrom(hex: (CommonClass.sharedInstance.myCard.address?.color)!)
        let fontName        	= (CommonClass.sharedInstance.myCard.address?.fontName)!
        let fontSize            = CGFloat((CommonClass.sharedInstance.myCard.address?.fontSize)!)
        self.lblAddress.font    = UIFont.init(name:fontName , size:fontSize)
        
        // BOLD
        if (CommonClass.sharedInstance.myCard.address?.isBold)! {
            let currentFont     = self.lblAddress.font
            self.lblAddress.font   = currentFont?.bold()
        }
        
        // ITALIC
        if (CommonClass.sharedInstance.myCard.address?.isItalic)! {
            let currentFont     = self.lblAddress.font
            self.lblAddress.font   = currentFont?.italic()
        }
        
        // BOLD + ITALIC
        if ((CommonClass.sharedInstance.myCard.address?.isBold)! && (CommonClass.sharedInstance.myCard.address?.isItalic)!) {
            let currentFont     = self.lblAddress.font
            self.lblAddress.font   = currentFont?.boldItalic()
        }
        
        // UNDERLINE
        self.lblAddress.underline(isUnderLine: (CommonClass.sharedInstance.myCard.address?.isUnderline)!)
    }
    
    
    //MARK:- Action Methods
    @IBAction func btnBack_Action(_ sender: UIButton) {
        if self.isEditCard {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context     = appDelegate.persistentContainer.viewContext
            context.reset()
            CommonClass.sharedInstance.myCard = nil
            CommonClass.sharedInstance.myCardUserImage = nil
            CommonClass.sharedInstance.myCardBackgroundImage = nil
        }
        
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSave_Action(_ sender: UIButton) {
        
        if (self.isCardDataValid()){
            self.hideButton(option: true)
            KRProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now()+1.0) {
                
                var cardBackgroundImageName = ""
                var cardUserImageName       = ""
                var cardName                = ""
                
                if self.isEditCard {
                    cardBackgroundImageName = CommonClass.sharedInstance.myCard.backgroundImageName!
                    cardUserImageName       = (CommonClass.sharedInstance.myCard.photo?.imageName!)!
                    cardName                = CommonClass.sharedInstance.myCard.cardImageName!
                }else{
                    cardBackgroundImageName = "background_" + CommonClass.sharedInstance.randomString(length: 8) + String(NSDate().timeIntervalSince1970) + ".png"
                    cardUserImageName       = "user_" + CommonClass.sharedInstance.randomString(length: 10) + String(NSDate().timeIntervalSince1970) + ".png"
                    cardName                = "card_" + CommonClass.sharedInstance.randomString(length: 8) + String(NSDate().timeIntervalSince1970) + ".png"
                }
                
                if (cardBackgroundImageName.count <= 0){
                    cardBackgroundImageName = "background_" + CommonClass.sharedInstance.randomString(length: 8) + String(NSDate().timeIntervalSince1970) + ".png"
                }
                
                if (cardUserImageName.count <= 0){
                    cardUserImageName       = "user_" + CommonClass.sharedInstance.randomString(length: 10) + String(NSDate().timeIntervalSince1970) + ".png"
                }
                
                if (cardName.count <= 0){
                    cardName                = "card_" + CommonClass.sharedInstance.randomString(length: 8) + String(NSDate().timeIntervalSince1970) + ".png"
                }
                
                
                
                if CommonClass.sharedInstance.myCardBackgroundImage != nil {
                    CommonClass.sharedInstance.myCard.backgroundImageName = CommonClass.sharedInstance.saveImageIn(cacheMemory: false, image: CommonClass.sharedInstance.myCardBackgroundImage, imageName: cardBackgroundImageName)
                }
                
                if CommonClass.sharedInstance.myCardUserImage != nil {
                    CommonClass.sharedInstance.myCard.photo?.imageName = CommonClass.sharedInstance.saveImageIn(cacheMemory: false, image: CommonClass.sharedInstance.myCardUserImage, imageName: cardUserImageName)
                }
                
                
                let cardImage = self.cardView.getImage()
                
                CommonClass.sharedInstance.myCard.cardImageName = CommonClass.sharedInstance.saveImageIn(cacheMemory: false, image: cardImage, imageName: cardName)
                
                
                CommonClass.sharedInstance.myCard = nil
                CommonClass.sharedInstance.myCardUserImage = nil
                CommonClass.sharedInstance.myCardBackgroundImage = nil
                KRProgressHUD.dismiss()
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                let context     = appDelegate.persistentContainer.viewContext
                do {
                    try context.save()
                    self.dismiss(animated: true, completion: nil);
                    CommonClass.sharedInstance.isNewCardInProgress          = false
                } catch {
                    print("Failed saving")
                }
                
                if (self.isEditCard){
                    self.navigationController?.popViewController(animated: true)
                }else{
                    self.dismiss(animated: true, completion: nil);
                }
                
            }
            
        }
        
    }
    
    
    @IBAction func btnAddBackground_Action(_ sender: UIButton) {
        self.gotoBackgroundSelectionView()
    }
    
    @IBAction func btnSelectLineColor_Action(_ sender: UIButton) {
        self.isLineColor = true
        self.showColorPickerController(color: CommonClass.sharedInstance.colorFrom(hex: CommonClass.sharedInstance.myCard.lineColor!))
    }
    
    @IBAction func btnEditImage_Action(_ sender: UIButton) {
        
        let actionSheet = UIAlertController.init(title: nil, message: "Card Photo", preferredStyle: UIAlertControllerStyle.actionSheet)
        let takePhoto   = UIAlertAction.init(title: "Take Photo", style: UIAlertActionStyle.default) { (alertAction) in
            let cameraVc        = UIImagePickerController()
            cameraVc.sourceType = UIImagePickerControllerSourceType.camera
            cameraVc.delegate   = self
            self.present(cameraVc, animated: true, completion: nil)
        }
        
        let choosePhoto = UIAlertAction.init(title: "Choose Photo", style: UIAlertActionStyle.default) { (alertAction) in
            actionSheet.dismiss(animated: true, completion: nil)
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "SelectBGViewController") as! SelectBGViewController
            vc.comingFromCardView   = true
            vc.isUserImage          = true
            vc.isCacheMemory        = !self.isEditCard
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        let cancel = UIAlertAction.init(title: "Cancel", style: UIAlertActionStyle.cancel) { (alertAction) in
            actionSheet.dismiss(animated: true, completion: nil)
        }
        
        actionSheet.addAction(takePhoto)
        actionSheet.addAction(choosePhoto)
        actionSheet.addAction(cancel)
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    @IBAction func btnEditName_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.Name)
    }
    
    @IBAction func btnEditOccupation_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.Occupation)
    }
    
    @IBAction func btnEditCompany_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.Company)
    }
    
    @IBAction func btnEditTelephoneNumber_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.HomePhone)
    }
    
    @IBAction func btnEditMobileNumber_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.MobilePhone)
    }
    
    @IBAction func btnEditEmail_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.Email)
    }
    
    @IBAction func btnEditAddress_Action(_ sender: UIButton) {
        self.showLabelEditingViewFor(type: LabelType.Address)
    }
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    //MARK: Gesture Handler
    
    @objc func wasDragged(gesture: UIPanGestureRecognizer) {
        // translation vector origin -> destination
        
        let translation = gesture.translation(in: self.cardView) // get the translation
        let label       = gesture.view! // the view inside the gesture
        
        let lblCenterPoint = CGPoint(x: label.center.x + translation.x, y: label.center.y + translation.y)
        
        if (lblCenterPoint.x - (label.frame.size.width/2)) < ((label == self.lblTelephoneNumber || label == self.lblMobileNumber) ? 40 : 10) {
            print("Left Out")
        } else if (lblCenterPoint.x + (label.frame.size.width/2)) > self.cardView.bounds.width - 10 {
            print("Right Out")
        }else if (lblCenterPoint.y - (label.frame.size.height/2)) < 10 {
            print("Top Out")
        } else if (lblCenterPoint.y + (label.frame.size.height/2)) > self.cardView.bounds.height - 10 {
            print("Bottom Out")
        }else{
            print("Inside")
            
            // move the label with the translation
            label.center = lblCenterPoint //CGPoint(x: label.center.x + translation.x, y: label.center.y + translation.y)
            
            if label == self.imageviewCardHolder {
                self.btnEditImage.frame = CGRect.init(x: label.frame.origin.x, y: label.frame.origin.y + (label.frame.size.height - self.btnEditImage.frame.size.height) , width: self.btnEditImage.frame.size.width, height: self.btnEditImage.frame.size.height)
            }
            
            if label == self.lblName {
                self.btnEditName.center = CGPoint.init(x: label.frame.origin.x, y: label.center.y)
            }
            if label == self.lblOccupation {
                self.btnEditOccupation.center = CGPoint.init(x: label.frame.origin.x + label.frame.size.width, y: label.center.y)
            }
            if label == self.lblCompany {
                self.btnEditCompany.center = CGPoint.init(x: label.frame.origin.x + label.frame.size.width, y: label.center.y)
            }
            if label == self.lblTelephoneNumber {
                self.imageViewTelephone.center      = CGPoint.init(x: label.frame.origin.x - 10 - (self.imageViewTelephone.frame.size.width/2), y: label.center.y)
                self.btnEditTelephoneNumber.center  = CGPoint.init(x: label.frame.origin.x + label.frame.size.width, y: label.center.y)
            }
            if label == self.lblMobileNumber {
                self.imageViewMobile.center      = CGPoint.init(x: label.frame.origin.x - 10 - (self.imageViewMobile.frame.size.width/2), y: label.center.y)
                self.btnEditMobileNumber.center  = CGPoint.init(x: label.frame.origin.x + label.frame.size.width, y: label.center.y)
            }
            if label == self.lblEmail {
                self.btnEditEmail.center = CGPoint.init(x: label.frame.origin.x + label.frame.size.width, y: label.center.y)
            }
            if label == self.lblAddress {
                self.btnEditAddress.center = CGPoint.init(x: label.frame.origin.x + label.frame.size.width, y: label.center.y)
            }
            
            
            // reset the translation that now, is already applied to the label
            gesture.setTranslation(CGPoint.zero, in: self.cardView)
            
            if gesture.state == UIGestureRecognizerState.ended{
                self.savePositions()
            }
            
        }
        
    }
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    //MARK:  Text Editing View
    func didTapOnCancel() {
        self.lblEditingView.removeFromSuperview()
        self.lblEditingView = nil
    }
    
    func didTapOnSaveForLabel(type: LabelType) {
        switch type {
        case .Name:
            self.setupName()
            break
        case .Occupation:
            self.setupOccupation()
            break
        case .Company:
            self.setupCompany()
            break
        case .HomePhone:
            self.setupHomeNumber()
            break
        case .MobilePhone:
            self.setupMobileNumber()
            break
        case .Email:
            self.setupEmail()
            break
        case .Address:
            self.setupAddress()
            break
            
        default:
            break
        }
        self.lblEditingView.removeFromSuperview()
    }
    
    func didTapOnColorButton(color: UIColor, colorCode: String) {
        self.isLineColor = false
        self.showColorPickerController(color:color)
    }
    
    
    //MARK: Image Picker
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        let tempImage               = info[UIImagePickerControllerOriginalImage] as! UIImage
        let cropViewController      = CropViewController(image: tempImage)
        cropViewController.delegate = self
        self.present(cropViewController, animated: true, completion: nil)
    }
    
    func cropViewController(_ cropViewController: CropViewController, didCropToImage image: UIImage, withRect cropRect: CGRect, angle: Int) {
        cropViewController.dismiss(animated: true, completion: nil)
        CommonClass.sharedInstance.myCardUserImage  = image
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    //MARK: Color Picker
    func colorViewController(colorViewCntroller: EFColorSelectionViewController, didChangeColor color: UIColor) {
        if self.isLineColor {
            self.cardView.layer.borderColor = color.cgColor
            self.cardView.layer.borderWidth = 1.0
            CommonClass.sharedInstance.myCard.lineColor = CommonClass.sharedInstance.getHexCodeFromColor(color: color)
        }else{
            if self.lblEditingView != nil {
                self.lblEditingView.updateLabelColor(color: color)
            }
        }
    }
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}



extension UIFont {
    func withTraits(traits:UIFontDescriptorSymbolicTraits) -> UIFont {
        let descriptor = fontDescriptor.withSymbolicTraits(traits)
        return UIFont(descriptor: descriptor!, size: 0.0)
    }
    
    func bold() -> UIFont {
//        return withTraits(traits: .traitBold)
        return fontDescriptor.withSymbolicTraits(fontDescriptor.symbolicTraits.union(.traitBold)).flatMap { UIFont(descriptor: $0, size: pointSize) } ?? self
    }
    
    func italic() -> UIFont {
//        return withTraits(traits: .traitItalic)
        return fontDescriptor.withSymbolicTraits(fontDescriptor.symbolicTraits.union(.traitItalic)).flatMap { UIFont(descriptor: $0, size: pointSize) } ?? self

    }
    
    func boldItalic() -> UIFont {
//        return withTraits(traits: [.traitItalic, .traitBold])
        return fontDescriptor.withSymbolicTraits(fontDescriptor.symbolicTraits.union([.traitItalic, .traitBold])).flatMap { UIFont(descriptor: $0, size: pointSize) } ?? self
    }
}

extension UILabel {
    func underline(isUnderLine:Bool) {
        if let textString = self.text {
            let attributedString = NSMutableAttributedString(string: textString)
            attributedString.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: NSRange(location: 0, length: isUnderLine ?  attributedString.length : 0))
            attributedText = attributedString
        }
    }
}


extension UIImagePickerController
{
    override open var shouldAutorotate: Bool {
        return false
    }
    override open var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return .landscape
    }
}
