//
//  ImagesViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 24/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import Photos
import KRProgressHUD
import CropViewController


class ImagesViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, CropViewControllerDelegate {
    
    
    //MARK: Properties
    var type:ImagesType!
    
    var photoAlbum:PHAssetCollection!   = PHAssetCollection.init()
    var arrayImages:NSMutableArray      = []
    var selectedIndex:Int!              = -1
    
    var comingFromCardView:Bool! = false
    var isUserImage:Bool! = false
    var isCacheMemory:Bool! = false
    
    //MARK: Outlets
    @IBOutlet weak var lblNavbarTitle: UILabel!
    @IBOutlet weak var btnDone: UIButton!
    
    @IBOutlet weak var collectionviewImages: UICollectionView!
    
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        if self.isUserImage {
            self.lblNavbarTitle.text     = "Profile Picture"
        }else{
            self.lblNavbarTitle.text     = "Background"
        }
        self.collectionviewImages.scrollsToTop  = true
        
        if self.type == ImagesType.ImagesTypeAlbum {
            if self.arrayImages.count <= 0{
                self.fetchPhotos()
            }
        }
        
        if self.type == ImagesType.ImagesTypeDark {
            for i in (1...10){
                let imageName  = String.init(format: "dark%d.png", i)
                self.arrayImages.add(UIImage.init(named: imageName) as Any)
            }
            self.collectionviewImages.reloadData()
        }
        
        if self.type == ImagesType.ImagesTypeLight {
            for i in (1...10){
                let imageName  = String.init(format: "light%d.png", i)
                self.arrayImages.add(UIImage.init(named: imageName) as Any)
            }
            self.collectionviewImages.reloadData()
        }
        
        
        self.updateDontButton()
    }
    
    //MARK:- Utility Methods
    
    func fetchPhotos() {
        KRProgressHUD.show()
        DispatchQueue.main.async {
            let fetchOptions    = PHFetchOptions()
            let sortOrder       = [NSSortDescriptor(key: "creationDate", ascending: false)]
            fetchOptions.sortDescriptors = sortOrder
            let result = PHAsset.fetchAssets(in: self.photoAlbum, options: fetchOptions)
            result.enumerateObjects({ (object, index, stop) -> Void in
                let asset = object
                self.arrayImages.add(CommonClass.sharedInstance.getAssetThumbnail(asset: asset))
            })
            
            self.collectionviewImages.reloadData()
            KRProgressHUD.dismiss()
        }
    }
    
    func updateDontButton() {
        if self.selectedIndex != -1 {
            self.btnDone.setTitle("DONE", for: UIControlState.normal)
            self.btnDone.isEnabled   = true
        }else{
            self.btnDone.setTitle("", for: UIControlState.normal)
            self.btnDone.isEnabled   = false
        }
    }
    
    func updateCellSelectionFor(itemNumber:Int) {
        if self.selectedIndex == -1 {
            self.selectedIndex = itemNumber
            let cell2 = self.collectionviewImages.cellForItem(at: IndexPath.init(row: self.selectedIndex, section: 0)) as! ImageCell
            cell2.btnCheck.isSelected = true
        }else if (itemNumber == self.selectedIndex){
            let cell = self.collectionviewImages.cellForItem(at: IndexPath.init(row: self.selectedIndex, section: 0)) as! ImageCell
            cell.btnCheck.isSelected = false
            self.selectedIndex = -1
        }else{
            let cell = self.collectionviewImages.cellForItem(at: IndexPath.init(row: self.selectedIndex, section: 0)) as! ImageCell
            cell.btnCheck.isSelected = false
            
            self.selectedIndex = itemNumber
            
            let cell2 = self.collectionviewImages.cellForItem(at: IndexPath.init(row: self.selectedIndex, section: 0)) as! ImageCell
            cell2.btnCheck.isSelected = true
        }
        
        self.updateDontButton()
    }
    
    func updatePhoto() {
        DispatchQueue.main.async {
            var selectedImage:UIImage? = nil
            CommonClass.sharedInstance.selectedBackgroundType = self.type
            
            if self.type == ImagesType.ImagesTypeAlbum{
                if self.selectedIndex > -1{
                    let fetchOptions    = PHFetchOptions()
                    let sortOrder       = [NSSortDescriptor(key: "creationDate", ascending: false)]
                    fetchOptions.sortDescriptors = sortOrder
                    let result          = PHAsset.fetchAssets(in: self.photoAlbum, options: fetchOptions)
                    let asset           = result[self.selectedIndex]
                    selectedImage       = CommonClass.sharedInstance.getAssetForMaxSize(asset: asset)
                }
            }else{
                selectedImage           = self.arrayImages.object(at: self.selectedIndex) as? UIImage
            }
            
            if (self.isUserImage){
                let cropViewController      = CropViewController(image: selectedImage!)
                cropViewController.delegate = self
                self.present(cropViewController, animated: true, completion: nil)
            }else{
                self.proceedWithSelectedImage(selectedImage: selectedImage!)
            }
            
            

        }
    }
    
    func cropViewController(_ cropViewController: CropViewController, didCropToImage image: UIImage, withRect cropRect: CGRect, angle: Int) {
        cropViewController.dismiss(animated: true, completion: nil)
        self.proceedWithSelectedImage(selectedImage: image)
    }
    
    func proceedWithSelectedImage(selectedImage:UIImage) {
        if (self.isUserImage){
            CommonClass.sharedInstance.myCardUserImage          = selectedImage
        }else{
            CommonClass.sharedInstance.myCardBackgroundImage        = selectedImage
            
            // Set Label Colors accordingly ~ Light / Dark
            let colorCode                                           = (self.type == ImagesType.ImagesTypeDark) ? "#ffffff" : "#000000"
            CommonClass.sharedInstance.myCard.name?.color           = colorCode
            CommonClass.sharedInstance.myCard.occupation?.color     = colorCode
            CommonClass.sharedInstance.myCard.company?.color        = colorCode
            CommonClass.sharedInstance.myCard.homeNumber?.color     = colorCode
            CommonClass.sharedInstance.myCard.mobileNumber?.color   = colorCode
            CommonClass.sharedInstance.myCard.email?.color          = colorCode
            CommonClass.sharedInstance.myCard.address?.color        = colorCode
        }
        
        if self.comingFromCardView {
            self.popToCardView()
        }else{
            NotificationCenter.default.post(name: Notification.Name.init(rawValue: "setBackgroundPhoto"), object: selectedImage, userInfo: nil)
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
    
    func popToCardView() {
        var vc:UIViewController!
        for myVC in self.navigationController!.viewControllers as NSArray{
            if (myVC as! UIViewController).isKind(of: EditCardViewController.self){
                vc = myVC as! UIViewController
                break
            }
        }
        self.navigationController?.popToViewController(vc, animated: true)
    }
    
    //MARK:- Action Methods
    @IBAction func btnBack_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCheck_Action(_ sender: UIButton) {
        self.updateCellSelectionFor(itemNumber: sender.tag);
    }
    
    @objc func imageTapGesture_Action(_ sender: UITapGestureRecognizer) {
        let imageView = sender.view as! UIImageView
        self.updateCellSelectionFor(itemNumber: imageView.tag);
    }
    
    @IBAction func btnDone_Action(_ sender: UIButton) {
        self.updatePhoto()
    }
    
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    //MARK:  CollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageCell", for: indexPath) as! ImageCell
        cell.image.image    = self.arrayImages.object(at: indexPath.row) as? UIImage
        cell.btnCheck.tag   = indexPath.row
        cell.image.tag      = indexPath.row
        if self.selectedIndex == indexPath.row {
            cell.btnCheck.isSelected = true
        }else{
            cell.btnCheck.isSelected = false
        }
        
        let tapGestuer = UITapGestureRecognizer.init(target: self, action: #selector(imageTapGesture_Action(_:)))
        cell.image.addGestureRecognizer(tapGestuer)
        
        return cell
    }
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
