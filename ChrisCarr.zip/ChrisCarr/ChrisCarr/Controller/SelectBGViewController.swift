//
//  SelectBGViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 24/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import Photos


enum ImagesType {
    case ImagesTypeLight
    case ImagesTypeDark
    case ImagesTypeAlbum
}

class SelectBGViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    //MARK: Properties
    var comingFromCardView:Bool! = false
    var isUserImage:Bool! = false
    var isCacheMemory:Bool! = false
    
    
    //MARK: Outlets
    
    var arrayAlbums:NSMutableArray! = NSMutableArray.init()
    
    @IBOutlet weak var lblNavbarTitle: UILabel!
    @IBOutlet weak var tableviewBackgrounds: UITableView!
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        if self.isUserImage {
            self.lblNavbarTitle.text     = "Profile Picture"
        }else{
            self.lblNavbarTitle.text     = "Background"
        }
        
        self.getAllAlbums()
        self.tableviewBackgrounds.scrollsToTop = true
    }
    
    
    //MARK:- Utility Methods
    func getAllAlbums() {
        
        PHPhotoLibrary.requestAuthorization { status in
            switch status {
            case .authorized:
                self.startFetchingAlbums()
                let fetchOptions = PHFetchOptions()
                let allPhotos = PHAsset.fetchAssets(with: .image, options: fetchOptions)
                print("Found \(allPhotos.count) assets")
            case .denied, .restricted:
                print("Not allowed")
            case .notDetermined:
                print("Not determined yet")
            }
        }
    }
    
    func startFetchingAlbums() {
        let fetchOptions    = PHFetchOptions()
        let allAlbums       = PHAssetCollection.fetchAssetCollections(with: .smartAlbum, subtype: .albumSyncedAlbum, options: fetchOptions)
        
        
        allAlbums.enumerateObjects{ (object: AnyObject!, count: Int, stop: UnsafeMutablePointer) in
            if object is PHAssetCollection {
                let album:PHAssetCollection = object as! PHAssetCollection
                let result = PHAsset.fetchAssets(in: album, options: fetchOptions)
                
                let albumTitle = album.localizedTitle?.lowercased()
                if (result.count > 0 && albumTitle?.range(of: "video") == nil && albumTitle?.range(of: "delete") == nil && albumTitle?.range(of: "slo") == nil){
                    self.arrayAlbums.add(object);
                }
            }
        }
        
        DispatchQueue.main.async {
            self.tableviewBackgrounds.reloadData()
        }
    }

    
    
    func gotoImagesViewControllerWithOption(type:ImagesType, index:Int) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImagesViewController") as! ImagesViewController
        vc.comingFromCardView   = self.comingFromCardView
        vc.isUserImage          = self.isUserImage
        vc.isCacheMemory        = self.isCacheMemory
        vc.type                 = type
        switch type {
        case .ImagesTypeAlbum:
            let album:PHAssetCollection = self.arrayAlbums.object(at: index) as! PHAssetCollection
            vc.photoAlbum = album
            break
        case .ImagesTypeLight:
            vc.photoAlbum = PHAssetCollection.init()
            break
        case .ImagesTypeDark:
            vc.photoAlbum = PHAssetCollection.init()
            break
        default:
            break
        }
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:- Action Methods
    @IBAction func btnBack_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnLight_Action(_ sender: UIButton) {
        self.gotoImagesViewControllerWithOption(type: ImagesType.ImagesTypeLight, index: 0)
    }
    
    @IBAction func btnDark_Action(_ sender: UIButton) {
        self.gotoImagesViewControllerWithOption(type: ImagesType.ImagesTypeDark, index:0)
    }
    
    //MARK:- DELEGATES
    
    //MARK:  TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.isUserImage {
            return  self.arrayAlbums.count
        }else{
            return  self.arrayAlbums.count + 1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 && !self.isUserImage{
            return 286.0
        }else{
            return 70.0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 && !self.isUserImage{
            let cell = tableView.dequeueReusableCell(withIdentifier: "staticCell")
            return cell!
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "albumCell") as! AlbumCell

            
            let album:PHAssetCollection = self.arrayAlbums.object(at: self.isUserImage ? indexPath.row : indexPath.row-1) as! PHAssetCollection
            let result = PHAsset.fetchAssets(in: album, options: nil)
            
            cell.lblTitle.text  = album.localizedTitle
            cell.lblCount.text  = String(describing: result.count)
            print(result.count)
            if result.count > 0{
                let asset = result.firstObject
                cell.imageAlbum.image   = CommonClass.sharedInstance.getAssetThumbnail(asset: asset!)
            }
            return cell
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.isUserImage{
            self.gotoImagesViewControllerWithOption(type: ImagesType.ImagesTypeAlbum, index: indexPath.row)
        }else if indexPath.row > 0 {
            self.gotoImagesViewControllerWithOption(type: ImagesType.ImagesTypeAlbum, index: indexPath.row-1)
//            let album:PHAssetCollection = self.arrayAlbums.object(at: indexPath.row-1) as! PHAssetCollection
//            self.gotoImagesViewControllerWithOption(type: ImagesType.ImagesTypeAlbum, album: album)
        }
    }
    
    
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
