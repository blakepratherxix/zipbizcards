//
//  PrintOptionViewController.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 11/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import PDFGenerator

class PrintOptionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    //MARK: Properties
    var selectedCard:Card!
    var paperSize:String = "Letter (8.5 × 11 inches [216 × 279 mm])"
    var isFillSheet:Bool = true
    
    //MARK: Outlets
    @IBOutlet weak var tableview: UITableView!
    
    //MARK:- View Life Cycle Starts here...
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setupView()
    }
    
    //MARK:- View Setup Methods
    func setupView() {
        
    }
    
    
    //MARK:- Utility Methods
    func showPaperSizePicker() {
        let arrayPaperSizes = ["Letter (8.5 × 11 inches [216 × 279 mm])","Legal (8.5 × 14 inches [216 × 357 mm])","A4 (8.3 × 11.7 inches [210 × 297 mm])","4 × 6 inches (102 × 152 mm)","5 × 7 inches (127 × 178 mm)","8 × 10 inches (203 × 254 mm)","16:9 wide (4 × 7.1 inches [102 × 181 mm])","A3 (11.7 × 16.5 inches [297 × 420 mm])","11 × 17 inches (279 × 432 mm)","13 × 19 inches (330 × 483 mm)"]
        ActionSheetStringPicker.show(withTitle: "Select Paper Size", rows: arrayPaperSizes, initialSelection: 0, doneBlock: { (picker, index, object) in
            self.paperSize = object as! String
            self.tableview.reloadData()
        }, cancel: nil, origin: self.view)
    }
    
    func getPaperSizeInPixels() -> CGRect {
        var pageRect = CGRect.zero
        
        if self.paperSize.lowercased().range(of: "letter") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 637.5, height: 825.0)
        }else if self.paperSize.lowercased().range(of: "legal") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 637.5, height: 1050.0)
        }else if self.paperSize.lowercased().range(of: "a4") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 622.5, height: 877.5)
        }else if self.paperSize.lowercased().range(of: "4 × 6") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 300, height: 450)
        }else if self.paperSize.lowercased().range(of: "5 × 7") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 375, height: 525)
        }else if self.paperSize.lowercased().range(of: "8 × 10") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 600, height: 750)
        }else if self.paperSize.lowercased().range(of: "16:9 wide") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 300, height: 532.5)
        }else if self.paperSize.lowercased().range(of: "a3") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 877.5, height: 1237.5)
        }else if self.paperSize.lowercased().range(of: "11 × 17") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 825, height: 1275)
        }else if self.paperSize.lowercased().range(of: "13 × 19") != nil {
            pageRect = CGRect.init(x: 0.0, y:0.0, width: 975, height: 1425)
        }
        
        return pageRect
    }
    
    func createPDF() {
        let cardImage       = CommonClass.sharedInstance.getImageFrom(isBackgroundImage: true, cacheMemory: false, imageName: self.selectedCard.cardImageName!)
        let paperFrame      = self.getPaperSizeInPixels()
        let pdfViewToRender = UIView.init(frame: paperFrame)

        if self.isFillSheet {
            let widthOfCard     = (paperFrame.size.width - 30)/2
            let updatedImage    = CommonClass.sharedInstance.resizeImageByKeepingAspectRatio(image: cardImage, targetSize: CGSize.init(width: widthOfCard, height: CGFloat(MAXFLOAT)))
            var imageY               = 10.0
            while ((imageY + Double(updatedImage.size.height)) < Double(paperFrame.size.height)){
                let imageView1       = UIImageView.init(frame: CGRect.init(x: 10, y: CGFloat(imageY), width: updatedImage.size.width, height: updatedImage.size.height))
                let imageView2       = UIImageView.init(frame: CGRect.init(x: 10+10+updatedImage.size.width, y: CGFloat(imageY), width: updatedImage.size.width, height: updatedImage.size.height))
                imageView1.image     = updatedImage
                imageView2.image     = updatedImage
                pdfViewToRender.addSubview(imageView1)
                pdfViewToRender.addSubview(imageView2)
                
                imageY = imageY + Double(updatedImage.size.height) + 10
            }
            
            
        }else{
            let updatedImage    = CommonClass.sharedInstance.resizeImageByKeepingAspectRatio(image: cardImage, targetSize: CGSize.init(width: 262.5, height: 150.0))
            let xOfImageView    = (paperFrame.size.width/2) - (updatedImage.size.width/2)
            let yOfImageView    = (paperFrame.size.height/2) - (updatedImage.size.height/2)
            let imageView       = UIImageView.init(frame: CGRect.init(x: xOfImageView, y: yOfImageView, width: updatedImage.size.width, height: updatedImage.size.height))
            imageView.image     = updatedImage
            pdfViewToRender.addSubview(imageView)
        }
        
        
        
        do {
            let page: [PDFPage] = [.view(pdfViewToRender)]
            let path = NSTemporaryDirectory().appending("sample1.pdf")
            try PDFGenerator.generate(page, to: path, password: "")
        } catch let error {
            print(error)
        }
    }
    
    
    //MARK:- Action Methods
    
    @IBAction func switchFillSheet_Action(_ sender: UISwitch, forEvent event: UIEvent) {
        self.isFillSheet    = sender.isOn
    }
    
    @IBAction func btnCancel_Action(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnForward_Action(_ sender: UIButton) {
        
        self.createPDF()
        let vc          = self.storyboard?.instantiateViewController(withIdentifier: "PDFViewerViewController") as! PDFViewerViewController
        vc.paperSize    = self.paperSize
        vc.selectedCard = self.selectedCard
        self.navigationController?.pushViewController(vc, animated: true)
    }
    //MARK:- DELEGATES
    
    //MARK:  TableView
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier1 = "rightDetailCell"
        let identifier2 = "switchCell"
        
        var cell:CardCell!
        
        if indexPath.row == 0{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier1) as! CardCell
            cell.lblTitle.text          = "Paper Size"
            cell.lblDetail.text         = self.paperSize
            cell.lblDetail.textColor    = UIColor.lightGray
        }else{
            cell = tableView.dequeueReusableCell(withIdentifier: identifier2) as! CardCell
            cell.lblTitle.text      = "Fill Sheet"
            cell.switchPhoto.setOn(self.isFillSheet, animated: false)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            self.showPaperSizePicker()
        }
    }
    
    //MARK:  TextField
    
    //MARK:  ScrollView
    
    
    
    //MARK:- View Life Cycle Ends here...
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
