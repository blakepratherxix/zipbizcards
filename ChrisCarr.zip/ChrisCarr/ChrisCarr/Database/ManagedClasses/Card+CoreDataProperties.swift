//
//  Card+CoreDataProperties.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 24/05/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//
//

import Foundation
import CoreData


extension Card {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Card> {
        return NSFetchRequest<Card>(entityName: "Card")
    }
    
    @nonobjc public class func entityDescription(context:NSManagedObjectContext) -> Card {
        return NSEntityDescription.insertNewObject(forEntityName: "Card", into: context) as! Card
    }

    @NSManaged public var backgroundImageName: String?
    @NSManaged public var cardImageName: String?
    @NSManaged public var lineColor: String?
    
    @NSManaged public var address: Address?
    @NSManaged public var company: Company?
    @NSManaged public var email: Email?
    @NSManaged public var homeNumber: HomeNumber?
    @NSManaged public var mobileNumber: MobileNumber?
    @NSManaged public var name: Name?
    @NSManaged public var occupation: Occupation?
    @NSManaged public var photo: Photo?

    
    @nonobjc public class func getAllCards(context:NSManagedObjectContext, completionHandler: @escaping(NSMutableArray) -> Void) {
        let request:NSFetchRequest<Card> = Card.fetchRequest()
        var allCards:NSMutableArray! = NSMutableArray.init()
        do{
            let array = try context.fetch(request)
            if array.count > 0{
                allCards = NSMutableArray.init(array: array)
            }
            completionHandler(allCards)
        }catch{
            print("failed to fetch data")
            completionHandler(allCards)
        }
    }
    
}
