//
//  CommonClass.swift
//  ChrisCarr
//
//  Created by Azeem Akram on 30/01/2018.
//  Copyright © 2018 BrainyApps. All rights reserved.
//

import UIKit
import Photos

let alertTitle = "ZipBizCards"

class CommonClass: NSObject {
    static let sharedInstance = CommonClass()
    var myCard:Card!
    var myCardBackgroundImage:UIImage!
    var myCardUserImage:UIImage!
    var selectedBackgroundType:ImagesType!
    var isNewCardInProgress:Bool = false
    
    
    
    
    func randomString(length: Int) -> String {
        let letters : NSString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        let len = UInt32(letters.length)
        
        var randomString = ""
        for _ in 0 ..< length {
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        return randomString
    }
    
    
    func getDocumentsDirectoryPath() -> URL{
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    func getCacheDirectoryPath() -> URL{
        let paths = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    func showAlertView(vc:UIViewController, title:String, message:String, buttons:[String], completionHandler:@escaping(_ buttonText:String, _ alertView:UIAlertController)-> Void) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        for buttonName in buttons {
            var style = UIAlertActionStyle.default
            if ((buttonName.lowercased().range(of: "delete") != nil) || (buttonName.lowercased().range(of: "cancel") != nil)) {
                style = UIAlertActionStyle.cancel
            }
            
            alert.addAction(UIAlertAction(title: buttonName, style: style, handler: { action in
                completionHandler(action.title!, alert)
                }
            ))
        }
        vc.present(alert, animated: true, completion: nil)
    }
    
    
    func getAssetThumbnail(asset: PHAsset) -> UIImage {
        let manager = PHImageManager.default()
        let option = PHImageRequestOptions()
        var thumbnail = UIImage()
        option.isSynchronous = true
        manager.requestImage(for: asset, targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFit, options: option, resultHandler: {(result, info)->Void in
            thumbnail = result!
        })
        return thumbnail
    }
    
    func getAssetForMaxSize(asset: PHAsset) -> UIImage {
        let manager = PHImageManager.default()
        let option = PHImageRequestOptions()
        var thumbnail = UIImage()
        option.isSynchronous = true
        manager.requestImage(for: asset, targetSize:PHImageManagerMaximumSize, contentMode: .aspectFit, options: option, resultHandler: {(result, info)->Void in
            thumbnail = result!
        })
        return thumbnail
    }
    
    func saveImageIn(cacheMemory:Bool, image:UIImage, imageName:String, completionHandler:@escaping(String)-> Void) {
        if let data = UIImagePNGRepresentation(image) {
            var filename = self.getDocumentsDirectoryPath().appendingPathComponent(imageName)
            if (cacheMemory){
                filename = self.getCacheDirectoryPath().appendingPathComponent(imageName)
            }
            do{
                try data.write(to: filename)
                completionHandler(filename.lastPathComponent)
            }catch{
                completionHandler("")
            }
        }else{
            completionHandler("")
        }
    }
    
    func saveImageIn(cacheMemory:Bool, image:UIImage, imageName:String) -> String {
        if let data = UIImagePNGRepresentation(image) {
            var filename = self.getDocumentsDirectoryPath().appendingPathComponent(imageName)
            if (cacheMemory){
                filename = self.getCacheDirectoryPath().appendingPathComponent(imageName)
            }
            do{
                try data.write(to: filename)
                return filename.lastPathComponent
            }catch{
                return ""
            }
        }else{
            return ""
        }
    }
    
    func getImageFrom(isBackgroundImage:Bool, cacheMemory:Bool, imageName:String) -> UIImage {
        var filename = self.getDocumentsDirectoryPath().appendingPathComponent(imageName)
        if (cacheMemory){
            filename = self.getCacheDirectoryPath().appendingPathComponent(imageName)
        }
        
        if let image = UIImage.init(contentsOfFile: filename.path) {
            return image
        }else{
            var imageName   = "avatar-circle"
            if isBackgroundImage{
                imageName   = "card-bg"
            }
            return UIImage.init(named: imageName)!
        }
    }
    
    
    func getHexCodeFromColor(color:UIColor) -> String {
        let ciColor = CIColor(color: color)
        let r:CGFloat = ciColor.red
        let g:CGFloat = ciColor.green
        let b:CGFloat = ciColor.blue
        var a:CGFloat = ciColor.alpha

        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        print(String(format: "#%06x", arguments: [rgb]))
        return String(format: "#%06x", arguments: [rgb])
    }
    
    func getRandomColor() -> UIColor {
        return UIColor(red:   CGFloat(arc4random()) / CGFloat(UInt32.max),
                       green: CGFloat(arc4random()) / CGFloat(UInt32.max),
                       blue:  CGFloat(arc4random()) / CGFloat(UInt32.max),
                       alpha: 1.0)
    }
    
    func colorFrom (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    func resizeImageByKeepingAspectRatio(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize.init(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize.init(width: size.width * widthRatio, height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect.init(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, true, 3.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
}

